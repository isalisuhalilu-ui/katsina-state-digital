# Katsina Digital

**Independent Civic-Tech Working Prototype — Katsina State, Nigeria**

Katsina Digital is an independently designed and deployed civic-technology prototype exploring how residents could access government information, public-service concepts, opportunities, and citizen-reporting workflows through one digital platform.

> **Project status:** Working prototype / pilot concept. This is **not an official Katsina State Government production platform**. Demo content is clearly identified where applicable.

## What I Built

As an independent developer, I designed and implemented the prototype's web experience and supporting application architecture, including:

- Government information and digital-service concepts
- Citizen issue reporting and request-tracking flows
- Education, jobs, agriculture, health and opportunity hubs
- Early-stage AI assistant presentation
- Responsive mobile-first interfaces
- English, Hausa and French localization concepts
- Authentication and role-based access concepts
- Backend API and PostgreSQL data layer
- API contract, validation and generated client tooling
- Deployment-ready configuration

## Technology Stack

| Area | Technologies |
|---|---|
| Frontend | React 19, TypeScript, Vite, Tailwind CSS v4, shadcn/ui |
| Routing | wouter |
| Backend | Node.js, Express 5 |
| Authentication | Clerk |
| Database | PostgreSQL, Drizzle ORM |
| API | OpenAPI, Zod, React Query/Orval-generated client |
| Tooling | pnpm workspace, TypeScript, Git/GitHub |
| AI | Provider-agnostic configuration for supported AI providers |
| Deployment | Netlify/Replit-compatible configuration, depending on deployment setup |

## Repository Structure

```text
artifacts/katsina-digital/   # Public web application
artifacts/api-server/        # Express API server
lib/db/                      # Database schema and migrations
lib/api-spec/                # OpenAPI specification
lib/api-zod/                 # Generated validation schemas
lib/api-client-react/        # Generated React API client/hooks
artifacts/mockup-sandbox/    # Internal design prototyping tool
scripts/                     # Development/maintenance scripts
```

## Running Locally

### Prerequisites

- Node.js 24
- pnpm 10+
- PostgreSQL
- Clerk application credentials for authentication features

### Install

```bash
pnpm install
```

### Environment

Copy each package's `.env.example` to `.env` and provide your own development credentials:

```bash
cp lib/db/.env.example lib/db/.env
cp artifacts/api-server/.env.example artifacts/api-server/.env
cp artifacts/katsina-digital/.env.example artifacts/katsina-digital/.env
```

**Never commit real API keys, database credentials, or `.env` files.**

### Database

```bash
pnpm --filter @workspace/db run push
```

### Start the API

```bash
pnpm --filter @workspace/api-server run dev
```

### Start the web app

```bash
pnpm --filter @workspace/katsina-digital run dev
```

### Test

```bash
pnpm --filter @workspace/api-server run test
```

## API Development

The API contract is defined in `lib/api-spec/openapi.yaml`. When request/response shapes change, update the OpenAPI specification first and regenerate the generated schemas/client rather than hand-editing generated files.

## Security & Prototype Limitations

This repository is presented as a portfolio/prototype project. Before any real public-sector production deployment, it would require a formal security review, infrastructure hardening, production secrets management, monitoring, backups, privacy/data-governance controls, accessibility validation, operational support, and deployment-specific object-storage configuration.

The shipped report-photo object-storage integration is deployment-specific; the current implementation notes explain the additional work required for non-Replit infrastructure.

## Portfolio Positioning

**Katsina Digital — Independent Civic-Tech Working Prototype**

This project demonstrates practical skills in web development, application architecture, API integration, authentication concepts, database-backed workflows, localization, deployment and product problem-solving.

It should not be represented as an officially commissioned or government-owned production system.

## Author

**Ibrahim Salisu**

Independent Technology Developer | Aspiring Cybersecurity Professional

- GitHub: `ADD_YOUR_GITHUB_URL`
- Portfolio: `ADD_YOUR_PORTFOLIO_URL`
- Live Demo: `ADD_YOUR_LIVE_DEMO_URL`
- Email: `ADD_YOUR_EMAIL`

## License

MIT
