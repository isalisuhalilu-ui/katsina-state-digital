# Katsina Digital — Phase 2 Implementation

This source bundle contains the Phase 2 security and user/report ownership foundation.

## Implemented
- Local PostgreSQL `users` model linked to Clerk user IDs.
- Clerk-to-local-user synchronization via `/api/auth/me`.
- `citizen_reports.user_id` ownership column with nullable foreign key for backwards compatibility.
- Authenticated report creation; the server derives ownership from the Clerk session.
- Citizen report listing restricted to the signed-in user's reports.
- Citizen report detail restricted to the owner; admin/staff can view reports.
- Dashboard summary restricted to the signed-in user's reports.
- Admin overview protected for `admin` and `staff` roles.
- Admin user count is now read from PostgreSQL.
- Added `staff` to the API role contract.
- Added SQL migrations under `lib/db/migrations/`.

## Migration order
1. `0001_create_users.sql`
2. `0002_add_report_user_ownership.sql`

Existing reports are preserved because `user_id` is nullable and uses `ON DELETE SET NULL`.

## Important
The source bundle does not contain production secrets. Apply the database migrations in the target environment before using the new ownership paths.
