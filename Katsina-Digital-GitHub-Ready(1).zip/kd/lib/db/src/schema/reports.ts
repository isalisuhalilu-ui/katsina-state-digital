import { createInsertSchema } from "drizzle-zod";
import { pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const reportsTable = pgTable("citizen_reports", {
  id: text("id").primaryKey(),
  reportId: text("report_id").notNull().unique(),
  userId: text("user_id").references(() => usersTable.id, { onDelete: "set null" }),
  category: text("category").notNull(),
  description: text("description").notNull(),
  photoPath: text("photo_path"),
  lga: text("lga").notNull(),
  location: text("location").notNull(),
  status: text("status").notNull().default("submitted"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertReportSchema = createInsertSchema(reportsTable).omit({
  createdAt: true,
  updatedAt: true,
});

export type InsertReport = z.infer<typeof insertReportSchema>;
export type Report = typeof reportsTable.$inferSelect;
