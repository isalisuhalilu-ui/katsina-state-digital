ALTER TABLE "citizen_reports"
ADD COLUMN IF NOT EXISTS "user_id" text;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM information_schema.table_constraints
    WHERE constraint_name = 'citizen_reports_user_id_users_id_fk'
      AND table_name = 'citizen_reports'
  ) THEN
    ALTER TABLE "citizen_reports"
      ADD CONSTRAINT "citizen_reports_user_id_users_id_fk"
      FOREIGN KEY ("user_id") REFERENCES "users"("id")
      ON DELETE SET NULL;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS "citizen_reports_user_id_idx"
  ON "citizen_reports" ("user_id");
