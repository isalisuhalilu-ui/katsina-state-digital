CREATE TABLE IF NOT EXISTS "users" (
  "id" text PRIMARY KEY NOT NULL,
  "clerk_user_id" text NOT NULL UNIQUE,
  "email" text NOT NULL UNIQUE,
  "first_name" text,
  "last_name" text,
  "phone" text,
  "lga" text,
  "role" text NOT NULL DEFAULT 'citizen',
  "profile_image" text,
  "created_at" timestamptz NOT NULL DEFAULT now(),
  "updated_at" timestamptz NOT NULL DEFAULT now()
);
