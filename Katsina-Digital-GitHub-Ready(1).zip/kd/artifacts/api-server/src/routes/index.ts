import { Router, type IRouter } from "express";
import healthRouter from "./health";
import platformRouter from "./platform";
import storageRouter from "./storage";
import authRouter from "./auth";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(platformRouter);
router.use(storageRouter);

export default router;
