import { getAuth } from "@clerk/express";
import { Router, type IRouter, type Request, type Response } from "express";
import { GetCurrentUserResponse } from "@workspace/api-zod";
import { getOrCreateLocalUser } from "../lib/auth";

const router: IRouter = Router();

router.get(
  "/auth/me",
  async (req: Request, res: Response): Promise<void> => {
    const { userId } = getAuth(req);
    if (!userId) {
      res.status(401).json({ error: "Not signed in" });
      return;
    }

    try {
      const user = await getOrCreateLocalUser(req);
      if (!user) {
        res.status(401).json({ error: "Not signed in" });
        return;
      }

      const name =
        [user.firstName, user.lastName].filter(Boolean).join(" ") || user.email;

      res.json(
        GetCurrentUserResponse.parse({
          id: user.id,
          clerkUserId: user.clerkUserId,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          phone: user.phone,
          lga: user.lga,
          role: user.role,
          profileImage: user.profileImage,
          createdAt: user.createdAt.toISOString(),
          name,
          joinedAt: user.createdAt.toISOString(),
        }),
      );
    } catch (error) {
      if (error instanceof Error && error.name === "MissingEmailError") {
        req.log.warn({ clerkUserId: userId }, error.message);
        res.status(422).json({ error: error.message });
        return;
      }
      req.log.error({ err: error, clerkUserId: userId }, "Unable to load user profile");
      res.status(500).json({ error: "Unable to load user profile" });
    }
  },
);

export default router;
