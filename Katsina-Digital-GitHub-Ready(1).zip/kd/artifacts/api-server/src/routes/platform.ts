import { Router, type IRouter, type Request, type Response } from "express";
import { randomUUID } from "node:crypto";
import { count, desc, eq } from "drizzle-orm";
import {
  AskAssistantBody,
  AskAssistantResponse,
  CreateReportBody,
  GetAdminOverviewResponse,
  GetDashboardSummaryResponse,
  GetHomeOverviewResponse,
  GetOpportunityParams,
  GetOpportunityResponse,
  GetReportParams,
  GetReportResponse,
  ListOpportunitiesQueryParams,
  ListOpportunitiesResponseItem,
  ListResourcesResponseItem,
  ListResourcesQueryParams,
} from "@workspace/api-zod";
import { db, reportsTable, usersTable } from "@workspace/db";
import { getOrCreateLocalUser, requireStaff } from "../lib/auth";
import { assistantRateLimiter, reportSubmissionRateLimiter } from "../lib/rateLimit";
import { askAssistant } from "../lib/aiAssistant";
import type {
  AdminOverview,
  DashboardSummary,
  HomeOverview,
  Lga,
  Opportunity,
  Report,
  Resource,
} from "@workspace/api-zod";

const router: IRouter = Router();

const lgaNames = [
  "Bakori",
  "Batagarawa",
  "Batsari",
  "Baure",
  "Bindawa",
  "Charanchi",
  "Dan Musa",
  "Dandume",
  "Danja",
  "Daura",
  "Dutsi",
  "Dutsin-Ma",
  "Faskari",
  "Funtua",
  "Ingawa",
  "Jibia",
  "Kafur",
  "Kaita",
  "Kankara",
  "Kankia",
  "Katsina",
  "Kurfi",
  "Kusada",
  "Mai'Adua",
  "Malumfashi",
  "Mani",
  "Mashi",
  "Matazu",
  "Musawa",
  "Rimi",
  "Sabuwa",
  "Safana",
  "Sandamu",
  "Zango",
] as const;

const lgas: Lga[] = lgaNames.map((name) => ({
  id: name.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
  name,
  isPilot: name === "Musawa",
  description:
    name === "Musawa"
      ? "Initial Pilot Concept — Musawa LGA"
      : "Katsina State Local Government Area",
}));

const opportunities: Opportunity[] = [
  {
    id: "demo-scholarship-001",
    title: "Community Scholarship Finder",
    organization: "Demo opportunity listing",
    category: "Scholarships",
    type: "Scholarship",
    lga: "All LGAs",
    deadline: "Demo deadline — verify before applying",
    description:
      "A sample listing showing how verified scholarship opportunities could be organized for residents.",
    sourceLabel: "DEMO DATA",
    status: "Open for demonstration",
    featured: true,
  },
  {
    id: "demo-skills-001",
    title: "Digital Skills Cohort",
    organization: "Demo opportunity listing",
    category: "Training",
    type: "Training",
    lga: "Musawa",
    deadline: "Demo deadline — verify before applying",
    description:
      "A sample skills opportunity for the Musawa pilot. This listing is not a real programme.",
    sourceLabel: "DEMO DATA",
    status: "Sample listing",
    featured: true,
  },
  {
    id: "demo-agri-001",
    title: "Smallholder Market Access",
    organization: "Demo opportunity listing",
    category: "Agriculture",
    type: "Agriculture",
    lga: "All LGAs",
    deadline: "Demo timing — verify before acting",
    description:
      "A sample agricultural resource showing how market information could be surfaced.",
    sourceLabel: "DEMO DATA",
    status: "Sample listing",
    featured: true,
  },
];

const resources: Resource[] = [
  {
    id: "education-scholarships",
    title: "Scholarships",
    domain: "education",
    category: "Education",
    summary: "Find and compare scholarship information in one place.",
    demoLabel: "DEMO DATA",
    actionLabel: "Explore scholarships",
  },
  {
    id: "education-admissions",
    title: "Admissions & JAMB",
    domain: "education",
    category: "Education",
    summary: "A future-ready guide to admissions, JAMB, WAEC and NECO resources.",
    demoLabel: "DEMO DATA",
    actionLabel: "View education resources",
  },
  {
    id: "education-learning",
    title: "Learning resources",
    domain: "education",
    category: "Education",
    summary: "Study support and learning links can live here as they are verified.",
    demoLabel: "DEMO DATA",
    actionLabel: "Browse resources",
  },
  {
    id: "jobs-opportunities",
    title: "Jobs & internships",
    domain: "jobs",
    category: "Jobs & Skills",
    summary: "A single place for jobs, internships and local skills opportunities.",
    demoLabel: "DEMO DATA",
    actionLabel: "Find opportunities",
  },
  {
    id: "jobs-cv",
    title: "CV assistance",
    domain: "jobs",
    category: "Jobs & Skills",
    summary: "Practical CV guidance designed for first-time and returning job seekers.",
    demoLabel: "DEMO DATA",
    actionLabel: "Get CV guidance",
  },
  {
    id: "agri-information",
    title: "Farming information",
    domain: "agriculture",
    category: "Agriculture",
    summary: "Seasonal farming resources and practical information for growers.",
    demoLabel: "DEMO DATA",
    actionLabel: "Explore agriculture",
  },
  {
    id: "agri-market",
    title: "Market information",
    domain: "agriculture",
    category: "Agriculture",
    summary: "Market information could help farmers make more informed decisions.",
    demoLabel: "DEMO DATA",
    actionLabel: "View market resources",
  },
  {
    id: "health-facilities",
    title: "Health facilities",
    domain: "health",
    category: "Health",
    summary: "A directory structure for verified facilities and public health resources.",
    demoLabel: "DEMO DATA",
    actionLabel: "Explore health resources",
  },
  {
    id: "health-information",
    title: "Health information",
    domain: "health",
    category: "Health",
    summary: "Plain-language health information can be published here when verified.",
    demoLabel: "DEMO DATA",
    actionLabel: "Browse health information",
  },
  {
    id: "government-information",
    title: "Government information",
    domain: "government",
    category: "Government",
    summary: "A structured place for ministries, agencies and public programmes.",
    demoLabel: "DEMO DATA",
    actionLabel: "Explore government information",
  },
  {
    id: "government-announcements",
    title: "Announcements",
    domain: "government",
    category: "Government",
    summary: "Announcements should only appear here after they are verified and sourced.",
    demoLabel: "DEMO DATA — No real announcement",
    actionLabel: "View demo announcements",
  },
];

const prototypeNotice =
  "Katsina Digital is currently a technology prototype designed to demonstrate how digital technology could improve access to information and citizen engagement across Katsina State. It is not yet an official government platform.";

const serializeReport = (row: typeof reportsTable.$inferSelect): Report => ({
  id: row.id,
  reportId: row.reportId,
  category: row.category,
  description: row.description,
  photoPath: row.photoPath ?? null,
  lga: row.lga,
  location: row.location,
  status: row.status as Report["status"],
  createdAt: row.createdAt.toISOString(),
  updatedAt: row.updatedAt.toISOString(),
});

router.get("/lgas", (_req, res) => {
  res.json(lgas);
});

router.get("/home/overview", (_req, res) => {
  res.json(
    GetHomeOverviewResponse.parse({
      stats: {
        lgaCount: lgas.length,
        opportunityCount: opportunities.length,
        resourceCount: resources.length,
      },
      featuredOpportunities: opportunities.filter((item) => item.featured),
      recentAnnouncements: resources.filter(
        (item) => item.domain === "government",
      ),
      pilotNotice: prototypeNotice,
    }),
  );
});

router.get("/opportunities", (req, res) => {
  const parsed = ListOpportunitiesQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid opportunity filters" });
    return;
  }
  const { type, lga, search } = parsed.data;
  const normalizedSearch = search?.toLowerCase();
  const result = opportunities.filter((item) => {
    const matchesType = !type || item.type.toLowerCase() === type.toLowerCase();
    const matchesLga = !lga || item.lga.toLowerCase() === lga.toLowerCase();
    const matchesSearch =
      !normalizedSearch ||
      [item.title, item.category, item.description, item.organization]
        .join(" ")
        .toLowerCase()
        .includes(normalizedSearch);
    return matchesType && matchesLga && matchesSearch;
  });
  res.json(result);
});

router.get("/opportunities/:id", (req, res) => {
  const parsed = GetOpportunityParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid opportunity id" });
    return;
  }
  const opportunity = opportunities.find((item) => item.id === parsed.data.id);
  if (!opportunity) {
    res.status(404).json({ error: "Opportunity not found" });
    return;
  }
  res.json(opportunity);
});

router.get("/resources", (req, res) => {
  const parsed = ListResourcesQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid resource filters" });
    return;
  }
  const { domain, search } = parsed.data;
  const normalizedSearch = search?.toLowerCase();
  res.json(
    resources.filter((item) => {
      const matchesDomain = !domain || item.domain === domain;
      const matchesSearch =
        !normalizedSearch ||
        [item.title, item.category, item.summary]
          .join(" ")
          .toLowerCase()
          .includes(normalizedSearch);
      return matchesDomain && matchesSearch;
    }),
  );
});

router.get("/reports", async (req, res) => {
  try {
    const access = await requireStaff(req);
    if (access.allowed) {
      const rows = await db
        .select()
        .from(reportsTable)
        .orderBy(desc(reportsTable.createdAt));
      res.json(rows.map(serializeReport));
      return;
    }

    if (!access.user) {
      res.status(401).json({ error: "Authentication required" });
      return;
    }

    const rows = await db
      .select()
      .from(reportsTable)
      .where(eq(reportsTable.userId, access.user.id))
      .orderBy(desc(reportsTable.createdAt));
    res.json(rows.map(serializeReport));
  } catch (error) {
    req.log.error({ err: error }, "Unable to list reports");
    res.status(500).json({ error: "Unable to load reports" });
  }
});

router.post("/reports", reportSubmissionRateLimiter, async (req, res) => {
  const parsed = CreateReportBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Please complete all report fields" });
    return;
  }

  try {
    const user = await getOrCreateLocalUser(req);
    if (!user) {
      res.status(401).json({ error: "Authentication required to submit a report" });
      return;
    }

    const id = randomUUID();
    const reportId = `KD-${new Date().getFullYear()}-${id.slice(0, 6).toUpperCase()}`;
    const created = new Date();
    const [row] = await db
      .insert(reportsTable)
      .values({
        id,
        reportId,
        userId: user.id,
        category: parsed.data.category,
        description: parsed.data.description,
        photoPath: parsed.data.photoPath ?? null,
        lga: parsed.data.lga,
        location: parsed.data.location,
        status: "submitted",
        createdAt: created,
        updatedAt: created,
      })
      .returning();
    res.status(201).json(serializeReport(row));
  } catch (error) {
    req.log.error({ err: error }, "Unable to create report");
    res.status(500).json({ error: "Unable to submit report" });
  }
});

router.get("/reports/:id", async (req, res) => {
  const parsed = GetReportParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid report id" });
    return;
  }
  try {
    const user = await getOrCreateLocalUser(req);
    if (!user) {
      res.status(401).json({ error: "Authentication required" });
      return;
    }

    const staff = user.role === "admin" || user.role === "staff";
    let [row] = await db
      .select()
      .from(reportsTable)
      .where(eq(reportsTable.id, parsed.data.id));
    if (!row) {
      [row] = await db
        .select()
        .from(reportsTable)
        .where(eq(reportsTable.reportId, parsed.data.id));
    }
    if (!row) {
      res.status(404).json({ error: "Report not found" });
      return;
    }

    if (!staff && row.userId !== user.id) {
      res.status(403).json({ error: "You are not allowed to view this report" });
      return;
    }

    res.json(serializeReport(row));
  } catch (error) {
    req.log.error({ err: error }, "Unable to load report");
    res.status(500).json({ error: "Unable to load report" });
  }
});

router.get("/dashboard/summary", async (req, res) => {
  try {
    const user = await getOrCreateLocalUser(req);
    if (!user) {
      res.status(401).json({ error: "Authentication required" });
      return;
    }

    const rows = await db
      .select()
      .from(reportsTable)
      .where(eq(reportsTable.userId, user.id))
      .orderBy(desc(reportsTable.createdAt));
    const reports = rows.map(serializeReport);
    res.json(
      GetDashboardSummaryResponse.parse({
        reportCount: reports.length,
        activeReportCount: reports.filter(
          (report) => report.status !== "resolved",
        ).length,
        savedCount: 0,
        notifications: 0,
        recentReports: reports.slice(0, 3),
      }),
    );
  } catch (error) {
    req.log.error({ err: error }, "Unable to load dashboard summary");
    res.status(500).json({ error: "Unable to load dashboard summary" });
  }
});

router.post("/assistant/ask", assistantRateLimiter, async (req, res) => {
  const parsed = AskAssistantBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Please enter a question" });
    return;
  }

  try {
    const result = await askAssistant(parsed.data);
    res.json(AskAssistantResponse.parse(result));
  } catch (error) {
    req.log.error({ err: error }, "AI assistant request failed");
    res.status(502).json({
      error: "The assistant is temporarily unavailable. Please try again shortly.",
    });
  }
});

router.get("/admin/overview", async (req, res) => {
  try {
    const access = await requireStaff(req);
    if (!access.allowed) {
      res.status(access.status).json({
        error: access.status === 401 ? "Authentication required" : "Admin or staff access required",
      });
      return;
    }

    const [reportCount, userCount] = await Promise.all([
      db.select({ count: count() }).from(reportsTable),
      db.select({ count: count() }).from(usersTable),
    ]);

    res.json(
      GetAdminOverviewResponse.parse({
        users: Number(userCount[0]?.count ?? 0),
        reports: Number(reportCount[0]?.count ?? 0),
        opportunities: opportunities.length,
        resources: resources.length,
        lgas: lgas.length,
      }),
    );
  } catch (error) {
    req.log.error({ err: error }, "Unable to load admin overview");
    res.status(500).json({ error: "Unable to load admin overview" });
  }
});

export default router;