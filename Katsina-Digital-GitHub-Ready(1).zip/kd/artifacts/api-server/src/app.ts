import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";
import { clerkMiddleware } from "@clerk/express";
import { publishableKeyFromHost } from "@clerk/shared/keys";
import {
  CLERK_PROXY_PATH,
  clerkProxyMiddleware,
  getClerkProxyHost,
} from "./middlewares/clerkProxyMiddleware";
import { corsOriginDelegate } from "./lib/corsConfig";
import { defaultRateLimiter } from "./lib/rateLimit";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(CLERK_PROXY_PATH, clerkProxyMiddleware());
// Origin allow-list is driven by ALLOWED_ORIGINS (comma-separated). In
// development, with no ALLOWED_ORIGINS set, all origins are allowed so local
// tooling (Vite dev server on a random port, mobile simulators, etc.) keeps
// working. In production, an unset ALLOWED_ORIGINS means NO cross-origin
// browser requests are permitted — same-origin (server serving the built
// SPA) still works, since browsers don't send an Origin header for that.
app.use(cors({ credentials: true, origin: corsOriginDelegate }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(
  clerkMiddleware((req) => ({
    publishableKey: publishableKeyFromHost(
      getClerkProxyHost(req) ?? "",
      process.env.CLERK_PUBLISHABLE_KEY,
    ),
  })),
);

// Baseline rate limiting for all API traffic. Individual routes that are
// especially abuse-prone (the AI assistant, report submission) apply a
// stricter limiter on top of this in their own route files.
app.use("/api", defaultRateLimiter);
app.use("/api", router);

export default app;
