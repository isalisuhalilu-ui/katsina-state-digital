import rateLimit from "express-rate-limit";
import { getAuth } from "@clerk/express";
import type { Request } from "express";

/**
 * NOTE ON SCALING: express-rate-limit's default store keeps counters in
 * memory on each process. That's fine for a single instance. If this API is
 * ever deployed across multiple instances/containers, swap in a shared
 * store (e.g. `rate-limit-redis`) so limits are enforced globally rather
 * than per-instance — otherwise a client can get N requests per instance.
 */

/**
 * Key by authenticated user when available, falling back to IP. This keeps
 * limits meaningful for logged-in citizens submitting reports or asking the
 * assistant, while still bounding anonymous/public traffic by IP.
 */
function keyByUserOrIp(req: Request): string {
  const { userId } = getAuth(req);
  return userId ?? req.ip ?? "unknown";
}

/** Baseline limiter applied to all /api traffic. Generous, just a backstop. */
export const defaultRateLimiter = rateLimit({
  windowMs: 60_000,
  limit: 120,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: keyByUserOrIp,
  message: { error: "Too many requests. Please slow down and try again shortly." },
});

/**
 * Stricter limiter for the AI assistant endpoint — each call is relatively
 * expensive (or, once a real provider is wired in, billed) and is a public
 * endpoint, so it's the most attractive target for abuse.
 */
export const assistantRateLimiter = rateLimit({
  windowMs: 60_000,
  limit: 10,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: keyByUserOrIp,
  message: {
    error: "Too many questions in a short time. Please wait a moment before asking again.",
  },
});

/** Limits how often a single user/IP can submit a citizen report. */
export const reportSubmissionRateLimiter = rateLimit({
  windowMs: 60_000 * 10,
  limit: 5,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: keyByUserOrIp,
  message: {
    error: "Too many reports submitted recently. Please wait before submitting another.",
  },
});
