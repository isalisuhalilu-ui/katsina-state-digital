import { describe, expect, it } from "vitest";
import { evaluateStaffAccess } from "../auth";

describe("evaluateStaffAccess", () => {
  it("denies with 401 when there is no authenticated user", () => {
    const result = evaluateStaffAccess(null);
    expect(result).toEqual({ allowed: false, status: 401 });
  });

  it("denies with 403 for a citizen role", () => {
    const result = evaluateStaffAccess("citizen");
    expect(result).toEqual({ allowed: false, status: 403 });
  });

  it("allows a staff role", () => {
    const result = evaluateStaffAccess("staff");
    expect(result).toEqual({ allowed: true, status: 200 });
  });

  it("allows an admin role", () => {
    const result = evaluateStaffAccess("admin");
    expect(result).toEqual({ allowed: true, status: 200 });
  });
});
