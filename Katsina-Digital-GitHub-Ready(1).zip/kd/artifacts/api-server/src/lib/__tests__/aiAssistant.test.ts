import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const ORIGINAL_ENV = { ...process.env };

async function loadAskAssistant() {
  const mod = await import("../aiAssistant");
  return mod.askAssistant;
}

describe("askAssistant", () => {
  beforeEach(() => {
    vi.resetModules();
    vi.unstubAllGlobals();
  });

  afterEach(() => {
    process.env = { ...ORIGINAL_ENV };
    vi.unstubAllGlobals();
  });

  it("returns an honest not-configured message (not a fabricated answer) when AI_PROVIDER is unset", async () => {
    delete process.env.AI_PROVIDER;
    const askAssistant = await loadAskAssistant();
    const result = await askAssistant({ question: "What documents do I need for a scholarship?", language: "english" });
    expect(result.language).toBe("english");
    expect(result.answer.toLowerCase()).toContain("not connected");
    expect(result.disclaimer).toBeTruthy();
  });

  it("returns the Hausa not-configured message when language is hausa", async () => {
    delete process.env.AI_PROVIDER;
    const askAssistant = await loadAskAssistant();
    const result = await askAssistant({ question: "Ina zan sami tallafin karatu?", language: "hausa" });
    expect(result.language).toBe("hausa");
    expect(result.answer.length).toBeGreaterThan(0);
  });

  it("does not attempt a network call when no provider is configured", async () => {
    delete process.env.AI_PROVIDER;
    const fetchSpy = vi.fn();
    vi.stubGlobal("fetch", fetchSpy);
    const askAssistant = await loadAskAssistant();
    await askAssistant({ question: "test", language: "english" });
    expect(fetchSpy).not.toHaveBeenCalled();
  });

  it("calls the Anthropic API when AI_PROVIDER=anthropic and returns its text", async () => {
    process.env.AI_PROVIDER = "anthropic";
    process.env.ANTHROPIC_API_KEY = "test-key";
    const fetchSpy = vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ content: [{ type: "text", text: "Here is your answer." }] }),
    });
    vi.stubGlobal("fetch", fetchSpy);
    const askAssistant = await loadAskAssistant();
    const result = await askAssistant({ question: "What is Katsina Digital?", language: "english" });
    expect(fetchSpy).toHaveBeenCalledTimes(1);
    expect(fetchSpy.mock.calls[0][0]).toBe("https://api.anthropic.com/v1/messages");
    expect(result.answer).toBe("Here is your answer.");
  });

  it("falls back to no provider when AI_PROVIDER=anthropic but the key is missing", async () => {
    process.env.AI_PROVIDER = "anthropic";
    delete process.env.ANTHROPIC_API_KEY;
    const fetchSpy = vi.fn();
    vi.stubGlobal("fetch", fetchSpy);
    const askAssistant = await loadAskAssistant();
    const result = await askAssistant({ question: "test", language: "english" });
    expect(fetchSpy).not.toHaveBeenCalled();
    expect(result.answer.toLowerCase()).toContain("not connected");
  });

  it("propagates an error when the provider call fails, rather than fabricating an answer", async () => {
    process.env.AI_PROVIDER = "anthropic";
    process.env.ANTHROPIC_API_KEY = "test-key";
    const fetchSpy = vi.fn().mockResolvedValue({ ok: false, status: 500 });
    vi.stubGlobal("fetch", fetchSpy);
    const askAssistant = await loadAskAssistant();
    await expect(
      askAssistant({ question: "test", language: "english" }),
    ).rejects.toThrow();
  });
});
