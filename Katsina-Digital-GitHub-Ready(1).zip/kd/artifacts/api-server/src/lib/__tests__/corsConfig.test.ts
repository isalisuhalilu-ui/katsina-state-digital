import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

// corsConfig.ts reads process.env at module load time, so each scenario
// needs a fresh module instance with env vars set beforehand.
async function loadDelegate() {
  const mod = await import("../corsConfig");
  return mod.corsOriginDelegate as (
    origin: string | undefined,
    callback: (err: Error | null, allow?: boolean) => void,
  ) => void;
}

function call(
  delegate: (origin: string | undefined, cb: (err: Error | null, allow?: boolean) => void) => void,
  origin: string | undefined,
): Promise<{ err: Error | null; allow?: boolean }> {
  return new Promise((resolve) => {
    delegate(origin, (err, allow) => resolve({ err, allow }));
  });
}

const ORIGINAL_ENV = { ...process.env };

describe("corsOriginDelegate", () => {
  beforeEach(() => {
    vi.resetModules();
  });

  afterEach(() => {
    process.env = { ...ORIGINAL_ENV };
  });

  it("always allows requests with no Origin header (same-origin, curl, server-to-server)", async () => {
    process.env.NODE_ENV = "production";
    process.env.ALLOWED_ORIGINS = "https://katsina.digital";
    const delegate = await loadDelegate();
    const result = await call(delegate, undefined);
    expect(result.err).toBeNull();
    expect(result.allow).toBe(true);
  });

  it("in development with no ALLOWED_ORIGINS set, allows any origin", async () => {
    process.env.NODE_ENV = "development";
    delete process.env.ALLOWED_ORIGINS;
    const delegate = await loadDelegate();
    const result = await call(delegate, "http://localhost:4321");
    expect(result.err).toBeNull();
    expect(result.allow).toBe(true);
  });

  it("in production with no ALLOWED_ORIGINS set, rejects any cross-origin request", async () => {
    process.env.NODE_ENV = "production";
    delete process.env.ALLOWED_ORIGINS;
    const delegate = await loadDelegate();
    const result = await call(delegate, "https://evil.example.com");
    expect(result.err).toBeInstanceOf(Error);
  });

  it("in production, allows an origin present in ALLOWED_ORIGINS", async () => {
    process.env.NODE_ENV = "production";
    process.env.ALLOWED_ORIGINS = "https://katsina.digital,https://www.katsina.digital";
    const delegate = await loadDelegate();
    const result = await call(delegate, "https://www.katsina.digital");
    expect(result.err).toBeNull();
    expect(result.allow).toBe(true);
  });

  it("in production, rejects an origin not present in ALLOWED_ORIGINS", async () => {
    process.env.NODE_ENV = "production";
    process.env.ALLOWED_ORIGINS = "https://katsina.digital";
    const delegate = await loadDelegate();
    const result = await call(delegate, "https://evil.example.com");
    expect(result.err).toBeInstanceOf(Error);
  });
});
