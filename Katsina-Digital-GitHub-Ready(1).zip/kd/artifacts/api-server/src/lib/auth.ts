import { clerkClient, getAuth } from "@clerk/express";
import type { Request } from "express";
import { randomUUID } from "node:crypto";
import { eq } from "drizzle-orm";
import { db, usersTable } from "@workspace/db";

export type AppRole = "citizen" | "admin" | "staff";

/**
 * Pure authorization decision, factored out of requireStaff() so it can be
 * unit tested without a database or Clerk client. Given a role (or no user
 * at all), decides whether staff-only access is permitted.
 */
export function evaluateStaffAccess(role: AppRole | null): {
  allowed: boolean;
  status: 401 | 403 | 200;
} {
  if (role === null) return { allowed: false, status: 401 };
  if (role !== "admin" && role !== "staff") return { allowed: false, status: 403 };
  return { allowed: true, status: 200 };
}

export function getAuthenticatedClerkUserId(req: Request): string | null {
  return getAuth(req).userId ?? null;
}

export async function getOrCreateLocalUser(req: Request) {
  const clerkUserId = getAuthenticatedClerkUserId(req);
  if (!clerkUserId) return null;

  const clerkUser = await clerkClient.users.getUser(clerkUserId);
  const email =
    clerkUser.primaryEmailAddress?.emailAddress ??
    clerkUser.emailAddresses[0]?.emailAddress;

  if (!email) {
    const error = new Error("Authenticated user has no email address");
    error.name = "MissingEmailError";
    throw error;
  }

  const now = new Date();
  const [user] = await db
    .insert(usersTable)
    .values({
      id: randomUUID(),
      clerkUserId: clerkUser.id,
      email,
      firstName: clerkUser.firstName,
      lastName: clerkUser.lastName,
      phone: clerkUser.primaryPhoneNumber?.phoneNumber ?? null,
      profileImage: clerkUser.imageUrl ?? null,
      role: "citizen",
      createdAt: now,
      updatedAt: now,
    })
    .onConflictDoUpdate({
      target: usersTable.clerkUserId,
      set: {
        email,
        firstName: clerkUser.firstName,
        lastName: clerkUser.lastName,
        phone: clerkUser.primaryPhoneNumber?.phoneNumber ?? null,
        profileImage: clerkUser.imageUrl ?? null,
        updatedAt: now,
      },
    })
    .returning();

  if (!user) throw new Error("Unable to synchronize user profile");
  return user;
}

export async function requireUser(req: Request) {
  const user = await getOrCreateLocalUser(req);
  if (!user) return null;
  return user;
}

export async function requireStaff(req: Request) {
  const user = await requireUser(req);
  const decision = evaluateStaffAccess(user ? (user.role as AppRole) : null);
  return { user, ...decision };
}

export async function isReportOwner(reportUserId: string | null, userId: string) {
  return reportUserId === userId;
}
