import type { CorsOptions } from "cors";
import { logger } from "./logger";

/**
 * Parses ALLOWED_ORIGINS (comma-separated list of origins, e.g.
 * "https://katsina.digital,https://www.katsina.digital") into a Set for
 * fast lookup. Empty/whitespace entries are dropped.
 */
function parseAllowedOrigins(): Set<string> {
  const raw = process.env.ALLOWED_ORIGINS || "";
  return new Set(
    raw
      .split(",")
      .map((origin) => origin.trim())
      .filter((origin) => origin.length > 0),
  );
}

const allowedOrigins = parseAllowedOrigins();
const isProduction = process.env.NODE_ENV === "production";

if (isProduction && allowedOrigins.size === 0) {
  logger.warn(
    "ALLOWED_ORIGINS is not set in production. Cross-origin browser " +
      "requests (credentialed) will be rejected. Same-origin requests " +
      "(e.g. the built SPA served from this same host) are unaffected. " +
      "Set ALLOWED_ORIGINS to a comma-separated list of trusted origins " +
      "if the frontend is hosted on a different origin than this API.",
  );
}

/**
 * CORS origin delegate for the `cors` package.
 *
 * - No Origin header (same-origin request, curl, server-to-server): allowed.
 * - Development with no ALLOWED_ORIGINS configured: allow any origin, since
 *   local dev often runs the SPA on an arbitrary Vite port.
 * - Otherwise: only origins explicitly listed in ALLOWED_ORIGINS are allowed.
 *   This replaces a permissive `origin: true` (reflect-any-origin), which is
 *   unsafe combined with `credentials: true` because it lets any website
 *   make authenticated, cookie-bearing requests to this API on a victim's
 *   behalf.
 */
export const corsOriginDelegate: CorsOptions["origin"] = (origin, callback) => {
  if (!origin) {
    callback(null, true);
    return;
  }

  if (!isProduction && allowedOrigins.size === 0) {
    callback(null, true);
    return;
  }

  if (allowedOrigins.has(origin)) {
    callback(null, true);
    return;
  }

  callback(new Error(`Origin not allowed: ${origin}`));
};
