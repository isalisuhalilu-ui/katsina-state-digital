import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import type { Report } from "@workspace/api-client-react";
import { demoNotifications, demoReports, demoSavedItemIds, type DemoNotification } from "@/demo-data";

export interface NewReportInput {
  category: string;
  description: string;
  lga: string;
  location: string;
  photoPath?: string | null;
}

interface DemoStoreShape {
  reports: Report[];
  addReport: (input: NewReportInput) => Report;
  findReport: (id: string) => Report | undefined;
  notifications: DemoNotification[];
  savedItemIds: string[];
}

const DemoStoreContext = createContext<DemoStoreShape | null>(null);

export function DemoStoreProvider({ children }: { children: ReactNode }) {
  const [reports, setReports] = useState<Report[]>(() => {
    if (typeof window === "undefined") return demoReports;
    try {
      const saved = window.localStorage.getItem("kcd-demo-reports");
      return saved ? JSON.parse(saved) as Report[] : demoReports;
    } catch { return demoReports; }
  });

  useEffect(() => {
    try { window.localStorage.setItem("kcd-demo-reports", JSON.stringify(reports)); } catch { /* demo persistence is best-effort */ }
  }, [reports]);

  const addReport = useCallback((input: NewReportInput): Report => {
    const now = new Date();
    const id = `demo-${now.getTime()}`;
    const reportId = `KD-${now.getFullYear()}-${id.slice(-6).toUpperCase()}`;
    const report: Report = {
      id,
      reportId,
      category: input.category,
      description: input.description,
      photoPath: input.photoPath ?? null,
      lga: input.lga,
      location: input.location,
      status: "submitted",
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
    };
    setReports((current) => [report, ...current]);
    return report;
  }, []);

  const findReport = useCallback((id: string) => reports.find((report) => report.id === id || report.reportId === id), [reports]);

  const value = useMemo<DemoStoreShape>(() => ({ reports, addReport, findReport, notifications: demoNotifications, savedItemIds: demoSavedItemIds }), [reports, addReport, findReport]);

  return <DemoStoreContext.Provider value={value}>{children}</DemoStoreContext.Provider>;
}

export function useDemoStore(): DemoStoreShape {
  const ctx = useContext(DemoStoreContext);
  if (!ctx) throw new Error("useDemoStore must be used within a DemoStoreProvider");
  return ctx;
}
