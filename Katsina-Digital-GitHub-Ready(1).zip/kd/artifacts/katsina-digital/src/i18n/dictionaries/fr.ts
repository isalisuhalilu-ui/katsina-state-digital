import type { Dictionary } from "./en";

/**
 * French dictionary. Keys must match en.ts exactly.
 */
const fr: Dictionary = {
  brand: {
    name: "Katsina Digital",
    tagline: "Pilote Katsina LGA",
  },
  nav: {
    education: "Éducation",
    jobs: "Emplois",
    agriculture: "Agriculture",
    health: "Santé",
    government: "Gouvernement",
    ai: "Katsina AI",
    signIn: "Connexion",
    reportIssue: "Signaler un problème",
  },
  footer: {
    findSupport: "Trouver de l'aide",
    takePart: "Participer",
    askAi: "Demander à Katsina AI",
    yourDashboard: "Votre tableau de bord",
    pilotArea: "Zone pilote",
    languages: "Haoussa · Anglais · Français",
    copyright: "© 2026 Katsina Digital · Un prototype de technologie civique. Les informations affichées peuvent être des exemples.",
  },
  common: {
    retry: "Réessayer",
    loading: "Chargement…",
    somethingWrong: "Quelque chose mérite d'être vérifié.",
    genericError: "Nous n'avons pas pu charger cette section. Veuillez réessayer.",
  },
  notice: {
    prototype:
      "Katsina Digital est actuellement un prototype technologique destiné à démontrer comment la technologie numérique pourrait améliorer l'accès à l'information et l'engagement citoyen dans l'État de Katsina. Ce n'est pas encore une plateforme gouvernementale officielle.",
  },
  languageSwitcher: {
    label: "Langue",
    english: "Anglais",
    hausa: "Haoussa",
    french: "Français",
  },
};

export default fr;
