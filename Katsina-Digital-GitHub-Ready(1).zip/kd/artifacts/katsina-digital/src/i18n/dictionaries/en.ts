/**
 * English dictionary (default language). Keys are grouped by the UI area
 * they belong to. Keep keys identical across en.ts / ha.ts / fr.ts — the
 * translation-completeness check in src/i18n/index.ts relies on it.
 */
const en = {
  brand: {
    name: "Katsina Digital",
    tagline: "Katsina LGA pilot",
  },
  nav: {
    education: "Education",
    jobs: "Jobs",
    agriculture: "Agriculture",
    health: "Health",
    government: "Government",
    ai: "Katsina AI",
    signIn: "Sign in",
    reportIssue: "Report an issue",
  },
  footer: {
    findSupport: "Find support",
    takePart: "Take part",
    askAi: "Ask Katsina AI",
    yourDashboard: "Your dashboard",
    pilotArea: "Pilot area",
    languages: "Hausa · English · French",
    copyright: "© 2026 Katsina Digital · A civic technology prototype. Information shown may be demo content.",
  },
  common: {
    retry: "Retry",
    loading: "Loading…",
    somethingWrong: "Something needs a second look.",
    genericError: "We could not load this section. Please try again.",
  },
  notice: {
    prototype:
      "Katsina Digital is currently a technology prototype designed to demonstrate how digital technology could improve access to information and citizen engagement across Katsina State. It is not yet an official government platform.",
  },
  languageSwitcher: {
    label: "Language",
    english: "English",
    hausa: "Hausa",
    french: "French",
  },
} as const;

// Widen every leaf value to `string` so other-language dictionaries (which
// naturally hold different literal strings) can be typed as `Dictionary`
// too. `as const` above is kept so key names stay literal (good
// autocomplete, and TypeScript will still catch a missing/misspelled key),
// while `DeepWiden` prevents English's literal *values* from becoming the
// required type for every other language.
type DeepWiden<T> = { [K in keyof T]: T[K] extends string ? string : DeepWiden<T[K]> };
export type Dictionary = DeepWiden<typeof en>;
export default en;
