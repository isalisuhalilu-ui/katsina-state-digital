import type { Dictionary } from "./en";

/**
 * Hausa dictionary. Keys must match en.ts exactly.
 */
const ha: Dictionary = {
  brand: {
    name: "Katsina Digital",
    tagline: "Katsina LGA pilot",
  },
  nav: {
    education: "Ilimi",
    jobs: "Ayyuka",
    agriculture: "Noma",
    health: "Lafiya",
    government: "Gwamnati",
    ai: "Katsina AI",
    signIn: "Shiga",
    reportIssue: "Kai rahoto",
  },
  footer: {
    findSupport: "Nemi taimako",
    takePart: "Shiga cikin aiki",
    askAi: "Tambayi Katsina AI",
    yourDashboard: "Dashboard naka",
    pilotArea: "Yankin gwaji",
    languages: "Hausa · Turanci · Faransanci",
    copyright: "© 2026 Katsina Digital · Wani samfurin fasahar jama'a. Bayanan da aka nuna na iya zama misali kawai.",
  },
  common: {
    retry: "Sake gwadawa",
    loading: "Ana lodi…",
    somethingWrong: "Wani abu na bukatar duba.",
    genericError: "Ba mu iya loda wannan sashe ba. Da fatan za a sake gwadawa.",
  },
  notice: {
    prototype:
      "Katsina Digital shiri ne na fasaha da ake gwadawa domin nuna yadda fasahar zamani za ta iya inganta samun bayanai da shigar da jama'a a cikin al'amuran Jihar Katsina. Har yanzu ba dandali ne na hukuma ba.",
  },
  languageSwitcher: {
    label: "Harshe",
    english: "Turanci",
    hausa: "Hausa",
    french: "Faransanci",
  },
};

export default ha;
