import { createContext, useContext, useMemo, useState, type ReactNode } from "react";
import { createElement } from "react";
import en, { type Dictionary } from "./dictionaries/en";
import ha from "./dictionaries/ha";
import fr from "./dictionaries/fr";

export type Language = "en" | "ha" | "fr";

export const LANGUAGES: Array<{ code: Language; labelKey: keyof Dictionary["languageSwitcher"] }> = [
  { code: "en", labelKey: "english" },
  { code: "ha", labelKey: "hausa" },
  { code: "fr", labelKey: "french" },
];

const dictionaries: Record<Language, Dictionary> = { en, ha, fr };

const STORAGE_KEY = "katsina-digital:language";
const DEFAULT_LANGUAGE: Language = "en";

function isLanguage(value: string | null): value is Language {
  return value === "en" || value === "ha" || value === "fr";
}

function readStoredLanguage(): Language {
  if (typeof window === "undefined") return DEFAULT_LANGUAGE;
  try {
    const stored = window.localStorage.getItem(STORAGE_KEY);
    return isLanguage(stored) ? stored : DEFAULT_LANGUAGE;
  } catch {
    // localStorage can throw in some privacy modes — fall back quietly.
    return DEFAULT_LANGUAGE;
  }
}

interface I18nContextValue {
  language: Language;
  setLanguage: (language: Language) => void;
  t: Dictionary;
}

const I18nContext = createContext<I18nContextValue | null>(null);

export function I18nProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>(readStoredLanguage);

  const setLanguage = (next: Language) => {
    setLanguageState(next);
    try {
      window.localStorage.setItem(STORAGE_KEY, next);
    } catch {
      // Ignore storage failures (private browsing, quota, etc.) — the
      // in-memory language state still updates for this session.
    }
  };

  const value = useMemo<I18nContextValue>(
    () => ({ language, setLanguage, t: dictionaries[language] }),
    [language],
  );

  return createElement(I18nContext.Provider, { value }, children);
}

/**
 * Access the active dictionary and the language switcher. Usage:
 *   const { t, language, setLanguage } = useTranslation();
 *   <h1>{t.brand.name}</h1>
 */
export function useTranslation(): I18nContextValue {
  const ctx = useContext(I18nContext);
  if (!ctx) {
    throw new Error("useTranslation must be used within an I18nProvider");
  }
  return ctx;
}
