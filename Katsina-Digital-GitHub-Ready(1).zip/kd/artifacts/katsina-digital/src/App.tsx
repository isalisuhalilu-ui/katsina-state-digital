import { useEffect, useMemo, useState } from "react";
import type { FormEvent, ReactNode } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ArrowRight, Bell, BookOpen, BriefcaseBusiness, Building2, CheckCircle2, ChevronRight, CircleAlert, FileText, Flag, HeartPulse, Landmark, Leaf, Menu, MessageCircle, Newspaper, Paperclip, Search, ShieldCheck, Sparkles, Upload, UserRound, X } from "lucide-react";
import { ClerkProvider, SignIn, SignUp } from "@clerk/react";
import { publishableKeyFromHost } from "@clerk/react/internal";
import { shadcn } from "@clerk/themes";
import { Link, Route, Router as WouterRouter, Switch, useLocation, useParams } from "wouter";
import type { AssistantAnswer, Lga, Report } from "@workspace/api-client-react";
import { getGetReportQueryKey, getListReportsQueryKey, useAskAssistant, useCreateReport, useGetAdminOverview, useGetCurrentUser, useGetDashboardSummary, useGetHomeOverview, useGetReport, useListLgas, useListOpportunities, useListReports, useListResources } from "@workspace/api-client-react";
import { ErrorBoundary } from "@/components/error-boundary";
import NotFound from "@/pages/not-found";
import { useTranslation, LANGUAGES, type Language } from "@/i18n";
import { DemoStoreProvider, useDemoStore, type NewReportInput } from "@/demo-store";
import {
  DEMO_LABEL,
  buildSearchIndex,
  demoAdminUsers,
  demoGovernmentDirectory,
  demoNews,
  demoOpportunities,
  demoResources,
  demoUser,
  fallbackLgas,
  suggestedSearches,
  type DemoOpportunity,
  type DemoResource,
  type GovernmentEntry,
  type NewsItem,
} from "@/demo-data";

const queryClient = new QueryClient();
const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");
const clerkPubKey = publishableKeyFromHost(window.location.hostname, import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const PROTOTYPE_TAG = "PROTOTYPE CONTENT";
const DEMO_MODE = import.meta.env.VITE_DEMO_MODE !== "false";
const NOTICE = "Katsina Civic Digital — V1.0 Concept Prototype. This prototype demonstrates a proposed digital civic-service experience. It is not an official Katsina State Government platform unless formally adopted and authorized.";

const fallbackOpportunities: DemoOpportunity[] = demoOpportunities;
const fallbackResources: DemoResource[] = demoResources;

function cx(...classes: Array<string | false | undefined>) { return classes.filter(Boolean).join(" "); }
function initials(name?: string | null) { return (name || "KD").split(" ").map((part) => part[0]).slice(0, 2).join("").toUpperCase(); }
function dateLabel(value?: string) { if (!value) return "Date to be confirmed"; const date = new Date(value); return Number.isNaN(date.getTime()) ? value : date.toLocaleDateString("en-NG", { day: "numeric", month: "short", year: "numeric" }); }
function errorMessage(error: unknown) { return error instanceof Error ? error.message : "We could not load this section. Please try again."; }

function Brand({ light = false }: { light?: boolean }) {
  const { t } = useTranslation();
  return <Link href="/" className="brand" data-testid="link-brand">
    <span className="brand-mark">K.</span>
    <span><span className={cx("brand-name", light && "text-white")}>{t.brand.name}</span><span className={cx("brand-sub", light && "text-white/60")}>{t.brand.tagline}</span></span>
  </Link>;
}

// `id` is a stable slug used for hrefs and data-testids; `labelKey` looks up
// the translated label from the active dictionary at render time.
const navItems = [
  { id: "education", href: "/education", labelKey: "education" as const },
  { id: "jobs", href: "/jobs", labelKey: "jobs" as const },
  { id: "agriculture", href: "/agriculture", labelKey: "agriculture" as const },
  { id: "health", href: "/health", labelKey: "health" as const },
  { id: "government", href: "/government", labelKey: "government" as const },
];

function LanguageSwitcher({ light = false }: { light?: boolean }) {
  const { language, setLanguage, t } = useTranslation();
  return <select
    aria-label={t.languageSwitcher.label}
    className={cx("language-switcher", light && "language-switcher-light")}
    value={language}
    onChange={(event) => setLanguage(event.target.value as Language)}
    data-testid="select-language"
  >
    {LANGUAGES.map(({ code, labelKey }) => <option key={code} value={code}>{t.languageSwitcher[labelKey]}</option>)}
  </select>;
}

function Header() {
  const [open, setOpen] = useState(false);
  const [location] = useLocation();
  const { t } = useTranslation();
  return <header className="site-header">
    <div className="container-wide header-inner">
      <Brand />
      <nav className="desktop-nav" aria-label="Primary navigation">{navItems.map((item) => <Link key={item.id} href={item.href} className={cx("nav-link", location.startsWith(item.href) && "active")} data-testid={`link-nav-${item.id}`}>{t.nav[item.labelKey]}</Link>)}</nav>
      <div className="header-actions">
        <LanguageSwitcher />
        <Link href="/search" className="btn btn-ghost btn-small" data-testid="link-header-search"><Search size={15} /> Search</Link>
        <Link href="/ai" className="btn btn-ghost btn-small" data-testid="link-header-ai"><Sparkles size={15} /> {t.nav.ai}</Link>
        <Link href="/sign-in" className="btn btn-primary btn-small" data-testid="link-header-sign-in">{t.nav.signIn}</Link>
        <button className="menu-button" onClick={() => setOpen(!open)} aria-label={open ? "Close menu" : "Open menu"} data-testid="button-mobile-menu">{open ? <X size={20} /> : <Menu size={20} />}</button>
      </div>
    </div>
    {open && <nav className="mobile-nav" aria-label="Mobile navigation">{navItems.map((item) => <Link key={item.id} href={item.href} className="nav-link" onClick={() => setOpen(false)} data-testid={`link-mobile-${item.id}`}>{t.nav[item.labelKey]}</Link>)}<Link href="/report" className="nav-link" onClick={() => setOpen(false)} data-testid="link-mobile-report">{t.nav.reportIssue}</Link></nav>}
  </header>;
}

function Footer() {
  const { t } = useTranslation();
  return <footer className="footer"><div className="container-wide footer-grid">
    <div><Brand light /><p className="notice-footer">{t.notice.prototype}</p></div>
    <div><h4>{t.footer.findSupport}</h4><div className="footer-links">{navItems.slice(0, 3).map((item) => <Link key={item.id} href={item.href} data-testid={`link-footer-${item.id}`}>{t.nav[item.labelKey]}</Link>)}</div></div>
    <div><h4>{t.footer.takePart}</h4><div className="footer-links"><Link href="/report" data-testid="link-footer-report">{t.nav.reportIssue}</Link><Link href="/ai" data-testid="link-footer-ai">{t.footer.askAi}</Link><Link href="/dashboard" data-testid="link-footer-dashboard">{t.footer.yourDashboard}</Link></div></div>
    <div><h4>{t.footer.pilotArea}</h4><p className="notice-footer">Katsina LGA<br />Katsina State, Nigeria<br /><br />{t.footer.languages}</p><div style={{ marginTop: 10 }}><LanguageSwitcher light /></div></div>
  </div><div className="container-wide footer-bottom">{t.footer.copyright}</div></footer>;
}

function Layout({ children }: { children: ReactNode }) { return <div className="page-shell"><Header />{children}<Footer /></div>; }
function PageHeading({ kicker, title, description }: { kicker: string; title: string; description: string }) { return <section className="page-heading"><div className="container-wide"><div className="eyebrow">{kicker}</div><h1>{title}</h1><p>{description}</p></div></section>; }
function QueryError({ error, onRetry }: { error: unknown; onRetry?: () => void }) { return <div className="error-box" data-testid="status-query-error"><strong>Something needs a second look.</strong><br />{errorMessage(error)} {onRetry && <button onClick={onRetry} className="btn btn-outline btn-small" style={{ marginTop: 10 }} data-testid="button-retry">Retry</button>}</div>; }
function Skeletons() { return <div className="loading-grid" data-testid="loading-content">{[1, 2, 3].map((item) => <div className="skeleton" key={item} />)}</div>; }
function EmptyState({ title, copy, icon: Icon = FileText }: { title: string; copy: string; icon?: typeof FileText }) { return <div className="empty-state" data-testid="empty-state"><Icon size={26} /><strong>{title}</strong><span>{copy}</span></div>; }

function Home() {
  const overview = useGetHomeOverview({ query: { enabled: !DEMO_MODE } });
  const lgas = useListLgas({ query: { enabled: !DEMO_MODE } });
  const data = overview.data;
  const opportunities = data?.featuredOpportunities?.length ? data.featuredOpportunities : fallbackOpportunities;
  const resources = data?.recentAnnouncements?.length ? data.recentAnnouncements : fallbackResources;
  const lgaCount = data?.stats?.lgaCount ?? lgas.data?.length ?? fallbackLgas.length;
  const [serviceQuery, setServiceQuery] = useState("");

  const serviceRoutes = [
    { icon: BookOpen, title: "Education", copy: "Scholarships, admissions and learning resources.", href: "/education", keywords: "education scholarship admission schools learning" },
    { icon: BriefcaseBusiness, title: "Jobs & Skills", copy: "Jobs, internships, training and enterprise opportunities.", href: "/jobs", keywords: "jobs skills internship training enterprise youth" },
    { icon: Leaf, title: "Agriculture", copy: "Farming information, markets, support and opportunities.", href: "/agriculture", keywords: "agriculture farming market farmer support" },
    { icon: HeartPulse, title: "Health", copy: "Health information, facilities and public programmes.", href: "/health", keywords: "health hospital facility programme" },
    { icon: Landmark, title: "Government", copy: "Government information, offices and public services.", href: "/government", keywords: "government ministry agency office service" },
  ];
  const q = serviceQuery.trim().toLowerCase();
  const filteredServices = q ? serviceRoutes.filter((item) => `${item.title} ${item.copy} ${item.keywords}`.toLowerCase().includes(q)) : serviceRoutes;

  return <Layout>
    <section className="hero">
      <div className="container-wide hero-inner">
        <div className="hero-content">
          <div className="eyebrow">KATSINA CIVIC DIGITAL · V1.0 CONCEPT PROTOTYPE</div>
          <h1>One Digital Gateway for Every Citizen</h1>
          <p className="hero-copy">A unified digital platform concept designed to connect citizens with government information, public services, opportunities and civic engagement.</p>
          <div className="hero-actions">
            <Link href="/government" className="btn btn-gold" data-testid="button-hero-explore">Explore Services <ArrowRight size={16} /></Link>
            <Link href="/ai" className="btn btn-outline" data-testid="button-hero-ai"><Sparkles size={15} /> Ask Civic AI</Link>
          </div>
          <div className="hero-proof">
            <span><ShieldCheck size={15} /> Citizen-first</span>
            <span><Landmark size={15} /> Government-ready concept</span>
            <span><MessageCircle size={15} /> Hausa · English · French</span>
          </div>
        </div>
        <div className="hero-dashboard-preview" aria-label="Digital government service preview">
          <div className="preview-top"><span className="preview-dot" /><span>Citizen service gateway</span><span className="preview-status">V1.0 DEMO</span></div>
          <div className="preview-main">
            <div className="preview-copy"><span className="preview-kicker">WELCOME</span><strong>How can we help?</strong><span>Find a service, ask Civic AI or track a request.</span></div>
            <div className="preview-actions">
              <Link href="/education"><BookOpen size={16} /> Education</Link><Link href="/jobs"><BriefcaseBusiness size={16} /> Jobs</Link><Link href="/agriculture"><Leaf size={16} /> Agriculture</Link><Link href="/health"><HeartPulse size={16} /> Health</Link><Link href="/government"><Landmark size={16} /> Government</Link><Link href="/ai"><Sparkles size={16} /> Civic AI</Link>
            </div>
          </div>
          <div className="preview-footer"><span>Designed for citizens</span><span>Katsina LGA pilot concept</span></div>
        </div>
      </div>
    </section>

    <main>
      <section className="section section-tight">
        <div className="container-wide"><div className="notice" data-testid="text-pilot-notice"><strong>Prototype notice:</strong> {data?.pilotNotice || NOTICE} <span style={{ display: "block", marginTop: 7 }}><strong>Pilot coverage:</strong> Katsina State · 34 LGAs · initial pilot focus: Katsina LGA.</span></div></div>
      </section>

      <section className="section quick-section">
        <div className="container-wide">
          <div className="section-head"><div><div className="section-kicker">Start here</div><h2 className="section-title">The fastest route to help.</h2><p className="section-sub">Four simple actions connect the citizen experience from discovery to follow-up.</p></div></div>
          <div className="quick-grid">
            {[
              { icon: Search, title: "Find a Service", copy: "Search government services and information.", href: "/search" },
              { icon: Sparkles, title: "Ask Civic AI", copy: "Get help finding information and next steps.", href: "/ai" },
              { icon: Flag, title: "Report an Issue", copy: "Tell government about a community problem.", href: "/report" },
              { icon: CheckCircle2, title: "Track a Request", copy: "Follow the progress of a submitted request.", href: "/reports" },
            ].map(({ icon: Icon, title, copy, href }) => <Link href={href} className="quick-action card-hover" key={title}><span className="quick-icon"><Icon size={19} /></span><span><strong>{title}</strong><small>{copy}</small></span><ArrowRight size={16} /></Link>)}
          </div>
        </div>
      </section>

      <section className="section service-section">
        <div className="container-wide">
          <div className="section-head">
            <div><div className="section-kicker">Government Services</div><h2 className="section-title">One service ecosystem.</h2><p className="section-sub">Find the public information or service area you need.</p></div>
            <Link href="/government" className="arrow-link">View all services <ChevronRight size={15} /></Link>
          </div>
          <div className="service-search">
            <Search size={18} aria-hidden="true" />
            <input aria-label="Search government services" value={serviceQuery} onChange={(e) => setServiceQuery(e.target.value)} placeholder="What government service are you looking for? Try scholarship, jobs, health…" />
            {serviceQuery && <button className="search-clear" onClick={() => setServiceQuery("")} aria-label="Clear search"><X size={16} /></button>}
          </div>
          <div className="search-meta">{q ? `${filteredServices.length} service areas found` : "Search by service, category or keyword"}</div>
          {filteredServices.length ? <div className="grid-3">{filteredServices.map(({ icon: Icon, title, copy, href }) => <Link href={href} className="card card-pad card-hover service-card" key={href}><div><div className="service-icon"><Icon size={20} /></div><h3>{title}</h3><p>{copy}</p></div><span className="arrow-link">Open service <ArrowRight size={14} /></span></Link>)}</div> : <div className="empty-state service-empty"><Search size={26} /><strong>No service area found</strong><span>Try a broader search such as “jobs”, “health”, “scholarship” or “government”.</span></div>}
        </div>
      </section>

      <section className="section ecosystem-section">
        <div className="container-wide">
          <div className="ecosystem-flow" aria-label="Citizen service journey">
            {[
              ["01", "FIND", "Discover a service or information.", "/search"],
              ["02", "REQUEST", "Submit a request or report.", "/report"],
              ["03", "TRACK", "Follow progress.", "/reports"],
              ["04", "RESOLVE", "Receive an update.", "/reports"],
            ].map(([number, title, copy, href]) => <Link href={href} className="flow-step flow-step-link" key={number} data-testid={`link-flow-${title.toLowerCase()}`}>
              <span>{number}</span><strong>{title}</strong><p>{copy}</p><em>Open {title.toLowerCase()} <ArrowRight size={13} /></em>
            </Link>)}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container-wide split-panel">
          <div className="ai-panel">
            <div className="eyebrow">KATSINA CIVIC AI</div>
            <h2>Your intelligent guide to government information and public services.</h2>
            <p>Ask practical questions in Hausa or English and get a clearer route to relevant services, opportunities and next actions.</p>
            <div className="ai-suggestions"><Link href="/ai?q=How can I find scholarship opportunities?" data-testid="link-home-ai-suggestion-1">How can I find scholarship opportunities?</Link><Link href="/ai?q=How can I report a community issue?" data-testid="link-home-ai-suggestion-2">How can I report a community issue?</Link></div>
            <Link href="/ai" className="btn btn-gold" data-testid="button-ai-entry">Ask Civic AI <MessageCircle size={16} /></Link>
          </div>
          <div className="impact-panel">
            <div className="section-kicker">Potential value</div>
            <h2 className="section-title" style={{ fontSize: "2rem" }}>Designed Around Citizens. Built for Better Access.</h2>
            <div className="impact-grid">
              {[
                ["Access", "Make public information easier to find.", "/search"],
                ["Engagement", "Give citizens a clearer way to communicate.", "/report"],
                ["Transparency", "Make service progress easier to understand.", "/reports"],
                ["Opportunity", "Connect citizens with education, jobs and programmes.", "/jobs"],
              ].map(([title, copy, href]) => <Link href={href} className="impact-link" key={title} data-testid={`link-impact-${title.toLowerCase()}`}>
                <strong>{title}</strong><span>{copy}</span><em>Explore <ArrowRight size={13} /></em>
              </Link>)}
            </div>
          </div>
        </div>
      </section>

      <section className="section section-soft">
        <div className="container-wide">
          <div className="section-head"><div><div className="section-kicker">Opportunities</div><h2 className="section-title">Discover the next opportunity.</h2><p className="section-sub">Demo listings show how citizens could find jobs, training and support.</p></div><Link href="/jobs" className="arrow-link">Explore opportunities <ChevronRight size={15} /></Link></div>
          {overview.isLoading ? <Skeletons /> : <div className="opportunity-grid">{opportunities.slice(0, 3).map((opportunity) => <OpportunityCard key={opportunity.id} opportunity={opportunity} />)}</div>}
        </div>
      </section>

      <section className="section section-tight">
        <div className="container-wide">
          <div className="stats-strip"><Link href="/opportunities" className="stat stat-link" data-testid="link-stat-opportunities"><div className="stat-value">{data?.stats?.opportunityCount ?? opportunities.length}</div><div className="stat-label">demo opportunities mapped</div><em>Explore opportunities <ArrowRight size={13} /></em></Link><Link href="/resources" className="stat stat-link" data-testid="link-stat-resources"><div className="stat-value">{data?.stats?.resourceCount ?? resources.length}</div><div className="stat-label">public resources in prototype</div><em>Browse resources <ArrowRight size={13} /></em></Link><Link href="/government" className="stat stat-link" data-testid="link-stat-lgas"><div className="stat-value">{lgaCount}</div><div className="stat-label">LGAs in the statewide prototype</div><em>View all 34 LGAs <ArrowRight size={13} /></em></Link></div>
          <p className="demo-caption"><span>DEMO DATA</span> Counts shown here are prototype values and do not represent verified statewide coverage.</p>
        </div>
      </section>
    </main>
  </Layout>;
}

function OpportunityCard({ opportunity }: { opportunity: DemoOpportunity }) {
  return <article className="card card-hover opportunity-card" data-testid={`card-opportunity-${opportunity.id}`}><div className="opportunity-top"><span className="tag">{opportunity.type}</span>{opportunity.featured && <span className="tag tag-gold">Featured</span>}</div><h3>{opportunity.title}</h3><div className="opportunity-meta">{opportunity.organization} · {opportunity.lga}</div><p className="opportunity-desc">{opportunity.description}</p><div className="opportunity-footer"><span className="deadline">Closes {dateLabel(opportunity.deadline)}</span><Link className="arrow-link" href={`/opportunities/${opportunity.id}`} data-testid={`link-opportunity-${opportunity.id}`}>Details <ArrowRight size={14} /></Link></div></article>;
}

const domainCopy: Record<string, { title: string; kicker: string; description: string; icon: typeof BookOpen; categories: string[] }> = {
  education: { title: "Education, from first question to next step.", kicker: "Education desk", description: "A calm place to find scholarships, admissions guidance, school information and learning resources.", icon: BookOpen, categories: ["Scholarships", "Admissions", "Schools", "JAMB", "WAEC / NECO", "Learning resources"] },
  jobs: { title: "Work, training and enterprise support.", kicker: "Jobs & enterprise desk", description: "Find the next opening, build a stronger application and discover support for an idea.", icon: BriefcaseBusiness, categories: ["Jobs", "Internships", "Training", "Entrepreneurship", "CV assistance"] },
  agriculture: { title: "Better information for the season ahead.", kicker: "Agriculture desk", description: "A practical directory for farming information, agricultural opportunities, market information and resources.", icon: Leaf, categories: ["Farming information", "Agricultural opportunities", "Market information", "Farming resources"] },
  health: { title: "Health information you can act on.", kicker: "Health desk", description: "Find health facilities, public health information and resources for residents and families.", icon: HeartPulse, categories: ["Health facilities", "Health information", "Public health resources"] },
  government: { title: "Public information, made easier to find.", kicker: "Government information", description: "Explore ministries, agencies, public programmes and clearly marked demo announcements.", icon: Landmark, categories: ["Ministries", "Agencies", "Public programmes", "Announcements"] },
};

function CatalogPage({ domain }: { domain: keyof typeof domainCopy }) {
  const config = domainCopy[domain];
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");
  const opportunitiesQuery = useListOpportunities({ search: search || undefined, type: domain === "jobs" ? undefined : undefined }, { query: { enabled: !DEMO_MODE } });
  const resourcesQuery = useListResources({ domain: domain as "education" | "jobs" | "agriculture" | "health" | "government" }, { query: { enabled: !DEMO_MODE } });
  const rawOpportunities = opportunitiesQuery.data?.filter((item) => item.category === domain) || fallbackOpportunities.filter((item) => item.category === domain);
  const rawResources = resourcesQuery.data?.length ? resourcesQuery.data : fallbackResources.filter((item) => item.domain === domain);
  const normalizedCategory = activeCategory.toLowerCase();
  const matchesCategory = (value: string) => activeCategory === "All" || value.toLowerCase().includes(normalizedCategory);
  const opportunities = rawOpportunities.filter((item) => matchesCategory(`${item.title} ${item.organization} ${item.type} ${item.category}`)).filter((item) => !search || `${item.title} ${item.organization} ${item.type}`.toLowerCase().includes(search.toLowerCase()));
  const resources = rawResources.filter((item) => matchesCategory(`${item.title} ${item.category} ${item.domain}`)).filter((item) => !search || `${item.title} ${item.summary}`.toLowerCase().includes(search.toLowerCase()));
  return <Layout><PageHeading kicker={config.kicker} title={config.title} description={config.description} /><main className="section"><div className="container-wide"><div className="filter-row"><div className="search-wrap"><Search size={17} /><input className="input" value={search} onChange={(event) => setSearch(event.target.value)} placeholder={`Search ${domain} information`} aria-label="Search information" data-testid={`input-search-${domain}`} /></div><select className="select" style={{ maxWidth: 205 }} value={activeCategory} onChange={(event) => setActiveCategory(event.target.value)} data-testid={`select-category-${domain}`}><option>All</option>{config.categories.map((category) => <option key={category}>{category}</option>)}</select></div><div className="grid-3" style={{ marginBottom: 36 }}>{config.categories.map((category, index) => { const Icon = config.icon; return <button className="card card-pad card-hover" style={{ textAlign: "left", cursor: "pointer", background: activeCategory === category ? "hsl(var(--secondary))" : undefined }} onClick={() => setActiveCategory(category)} key={category} data-testid={`button-category-${domain}-${index}`}><div className="service-icon"><Icon size={18} /></div><h3 style={{ color: "hsl(var(--primary))", margin: "0 0 4px", fontSize: ".94rem" }}>{category}</h3><p style={{ color: "hsl(var(--muted-foreground))", fontSize: ".75rem", margin: 0 }}>Browse this route</p></button>; })}</div><div className="section-head"><div><div className="section-kicker">{activeCategory === "All" ? "Latest listings" : activeCategory}</div><h2 className="section-title" style={{ fontSize: "2rem" }}>{domain === "government" ? "Information shelf" : "Opportunities in the pilot"}</h2></div><span className="tag tag-gold">{opportunities.length + resources.length} items</span></div>{(!DEMO_MODE && (opportunitiesQuery.isLoading || resourcesQuery.isLoading)) ? <Skeletons /> : <div className="opportunity-grid">{opportunities.length || domain === "government" ? opportunities.slice(0, 6).map((item) => <OpportunityCard key={item.id} opportunity={item} />) : <EmptyState icon={config.icon} title="Nothing matches that search yet" copy="Try another phrase or return to all categories." />}{resources.slice(0, 6).map((resource) => <Link href={`/resources/${resource.id}`} className="card card-pad card-hover" key={resource.id} data-testid={`card-resource-${resource.id}`}><span className="tag">{resource.category}</span><h3 style={{ color: "hsl(var(--primary))", margin: "15px 0 7px", fontSize: "1rem" }}>{resource.title}</h3><p style={{ color: "hsl(var(--muted-foreground))", lineHeight: 1.55, fontSize: ".8rem" }}>{resource.summary}</p><span className="form-help">{resource.demoLabel}</span></Link>)}</div>}
      {domain === "government" && <>
        <div className="section-head" style={{ marginTop: 40 }}><div><div className="section-kicker">Directory</div><h2 className="section-title" style={{ fontSize: "1.7rem" }}>Ministries, agencies & offices.</h2><p className="section-sub">Illustrative directory entries — not verified government contact information.</p></div></div>
        <div className="grid-3" style={{ marginBottom: 36 }}>{demoGovernmentDirectory.filter((item) => !search || `${item.name} ${item.category}`.toLowerCase().includes(search.toLowerCase())).map((entry) => <Link href={`/government/${entry.id}`} className="card card-pad card-hover" key={entry.id} data-testid={`card-government-${entry.id}`}><span className="tag">{entry.category}</span><h3 style={{ color: "hsl(var(--primary))", margin: "12px 0 6px", fontSize: ".95rem" }}>{entry.name}</h3><p style={{ color: "hsl(var(--muted-foreground))", fontSize: ".78rem", lineHeight: 1.5 }}>{entry.description}</p></Link>)}</div>
        <div className="section-head" style={{ marginTop: 40 }}><div><div className="section-kicker">Statewide coverage</div><h2 className="section-title" style={{ fontSize: "1.7rem" }}>34 Local Government Areas.</h2><p className="section-sub">All 34 LGAs are available in the prototype. Katsina LGA is marked as the initial pilot focus.</p></div><span className="tag tag-gold">34 / 34 LGAs</span></div>
        <div className="grid-3" style={{ marginBottom: 36 }}>{fallbackLgas.map((lga) => <Link href={`/lga/${lga.id}`} className="card card-pad card-hover" key={lga.id} data-testid={`card-lga-${lga.id}`}><div style={{ display: "flex", justifyContent: "space-between", gap: 8, alignItems: "start" }}><span className="tag">LGA</span>{lga.isPilot && <span className="tag tag-gold">Pilot</span>}</div><h3 style={{ color: "hsl(var(--primary))", margin: "12px 0 6px", fontSize: ".95rem" }}>{lga.name}</h3><p style={{ color: "hsl(var(--muted-foreground))", fontSize: ".78rem", lineHeight: 1.5 }}>{lga.isPilot ? "Initial pilot focus within the statewide concept." : "Statewide prototype coverage."}</p><span className="form-help">View LGA details →</span></Link>)}</div>
        <div className="section-head"><div><div className="section-kicker">News</div><h2 className="section-title" style={{ fontSize: "1.7rem" }}>Announcements.</h2><p className="section-sub">DEMO / PROTOTYPE CONTENT only — no real announcement is represented here.</p></div></div>
        <div className="grid-3">{demoNews.map((item) => <Link href={`/news/${item.id}`} className="card card-pad card-hover" key={item.id} data-testid={`card-news-${item.id}`}><span className="tag tag-gold">{item.category}</span><h3 style={{ color: "hsl(var(--primary))", margin: "12px 0 6px", fontSize: ".95rem" }}>{item.title}</h3><p style={{ color: "hsl(var(--muted-foreground))", fontSize: ".78rem", lineHeight: 1.5 }}>{item.summary}</p><span className="form-help">{dateLabel(item.date)}</span></Link>)}</div>
      </>}
    </div></main></Layout>;
}

function ReportPage() {
  const lgas = useListLgas({ query: { enabled: !DEMO_MODE } });
  const createReport = useCreateReport();
  const demoStore = useDemoStore();
  const [form, setForm] = useState({ name: demoUser.name, email: demoUser.email, phone: demoUser.phone, category: "Roads", description: "", photoPath: "", lga: "Katsina", location: "" });
  const [fileName, setFileName] = useState("");
  const [submitted, setSubmitted] = useState<Report | null>(null);
  const [usedDemoFallback, setUsedDemoFallback] = useState(false);
  const update = (key: keyof typeof form, value: string) => setForm((current) => ({ ...current, [key]: value }));
  const submitToDemoStore = (input: NewReportInput) => { const report = demoStore.addReport(input); setSubmitted(report); setUsedDemoFallback(true); };
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (form.description.trim().length < 10 || !form.location.trim()) return;
    const reportInput: NewReportInput = { category: form.category, description: form.description, lga: form.lga, location: form.location, photoPath: form.photoPath || null };
    if (DEMO_MODE) { submitToDemoStore(reportInput); return; }
    createReport.mutate({ data: { category: form.category, description: form.description, lga: form.lga, location: form.location, photoPath: form.photoPath || null } }, {
      onSuccess: (report) => { setSubmitted(report); setUsedDemoFallback(false); queryClient.invalidateQueries({ queryKey: getListReportsQueryKey() }); },
      onError: () => submitToDemoStore(reportInput),
    });
  };
  return <Layout><PageHeading kicker="Citizen voice" title="Report a local issue." description="Tell us what needs attention. This prototype shows how a clear, trackable report could move from a resident to a responsible team." /><main className="section"><div className="container-wide"><div className="notice" style={{ marginBottom: 18 }}><strong>Report safely.</strong> Please do not include passwords, financial details or another person’s private information.</div>{submitted ? <div className="card form-card" data-testid="success-report"><div className="success-box"><CheckCircle2 size={18} style={{ verticalAlign: "middle", marginRight: 6 }} /> REPORT SUBMITTED. Your report has been received.</div><div className="eyebrow">Your report ID</div><h2 style={{ color: "hsl(var(--primary))", fontFamily: "var(--app-font-mono)", fontSize: "1.9rem", margin: "8px 0" }}>{submitted.reportId}</h2><p className="form-help"><strong>Category:</strong> {submitted.category} · <strong>LGA:</strong> {submitted.lga} · <strong>Date:</strong> {dateLabel(submitted.createdAt)} · <strong>Status:</strong> {submitted.status.replace("_", " ")}</p><p className="form-help">Keep this ID to check progress. We will show updates here as the report moves through review.</p>{usedDemoFallback && <div className="notice" style={{ marginTop: 14 }}><strong>Prototype demonstration.</strong> This submission was recorded in this browser session's demo tracker (no authenticated session was available) so you can still see the full report → track journey.</div>}<div style={{ display: "flex", gap: 9, flexWrap: "wrap", marginTop: 20 }}><Link className="btn btn-primary" href={`/reports/${submitted.id}`} data-testid="link-view-submitted-report">Track this request</Link><button className="btn btn-outline" onClick={() => { setSubmitted(null); setForm({ name: demoUser.name, email: demoUser.email, phone: demoUser.phone, category: "Roads", description: "", photoPath: "", lga: "Katsina", location: "" }); }} data-testid="button-submit-another">Submit another</button></div></div> : <form className="card form-card" onSubmit={submit} data-testid="form-report"><div className="form-grid"><div className="form-field"><label className="label" htmlFor="report-name">Full name</label><input id="report-name" className="input" value={form.name} onChange={(event) => update("name", event.target.value)} data-testid="input-report-name" /></div><div className="form-field"><label className="label" htmlFor="report-email">Email</label><input id="report-email" className="input" value={form.email} onChange={(event) => update("email", event.target.value)} data-testid="input-report-email" /></div><div className="form-field full"><label className="label" htmlFor="report-phone">Phone number</label><input id="report-phone" className="input" value={form.phone} onChange={(event) => update("phone", event.target.value)} data-testid="input-report-phone" /><span className="form-help">Pre-filled with your demo profile. Edit as needed.</span></div><div className="form-field"><label className="label" htmlFor="report-category">What is the issue?</label><select id="report-category" className="select" value={form.category} onChange={(event) => update("category", event.target.value)} data-testid="select-report-category"><option>Roads</option><option>Water</option><option>Waste Management</option><option>Electricity</option><option>Education</option><option>Healthcare</option><option>Other</option></select></div><div className="form-field"><label className="label" htmlFor="report-lga">LGA</label><select id="report-lga" className="select" value={form.lga} onChange={(event) => update("lga", event.target.value)} data-testid="select-report-lga">{(lgas.data?.length ? lgas.data : fallbackLgas).map((lga) => <option key={lga.id}>{lga.name}</option>)}</select></div><div className="form-field full"><label className="label" htmlFor="report-description">Describe what happened</label><textarea id="report-description" className="textarea" value={form.description} onChange={(event) => update("description", event.target.value)} placeholder="Share the key details: what you saw, when it started and who may be affected." data-testid="textarea-report-description" /><span className="form-help">At least 10 characters. Clear details help a future team understand the issue.</span></div><div className="form-field full"><label className="label" htmlFor="report-location">Location or nearest landmark</label><input id="report-location" className="input" value={form.location} onChange={(event) => update("location", event.target.value)} placeholder="For example: near Katsina Central Market" data-testid="input-report-location" /></div><div className="form-field full"><label className="label" htmlFor="report-photo">Photo (optional)</label><div style={{ display: "flex", gap: 9, alignItems: "center" }}><label className="btn btn-outline btn-small" htmlFor="report-photo" style={{ cursor: "pointer" }} data-testid="button-report-photo"><Upload size={15} /> Attach a photo</label><input id="report-photo" type="file" accept="image/*" hidden onChange={(event) => setFileName(event.target.files?.[0]?.name || "")} data-testid="input-report-photo" />{fileName && <span className="form-help"><Paperclip size={13} style={{ verticalAlign: "middle" }} /> {fileName}</span>}</div><span className="form-help">Photo upload is shown as an affordance in this pilot. Files will be connected to secure object storage when enabled.</span></div></div>{createReport.isError && <div className="error-box" style={{ marginTop: 18 }} data-testid="status-report-error"><CircleAlert size={16} style={{ verticalAlign: "middle", marginRight: 5 }} /> We could not submit this report. Check your connection and try again.</div>}<button className="btn btn-primary" type="submit" disabled={createReport.isPending || form.description.trim().length < 10 || !form.location.trim()} style={{ marginTop: 22 }} data-testid="button-submit-report">{createReport.isPending ? "Sending report…" : "Submit report"} <ArrowRight size={16} /></button></form>}</div></main></Layout>;
}

function ReportsPage() {
  const reportsQuery = useListReports({ query: { enabled: !DEMO_MODE } });
  const demoStore = useDemoStore();
  const reports = reportsQuery.data?.length ? reportsQuery.data : demoStore.reports;
  const isDemoSet = !reportsQuery.data?.length;
  const [lookup, setLookup] = useState("");
  const matched = lookup.trim() ? reports.find((report) => report.reportId.toLowerCase() === lookup.trim().toLowerCase() || report.id === lookup.trim()) : null;
  return <Layout><PageHeading kicker="Your civic trail" title="Reports and status." description="Keep an eye on issues you have submitted and see the latest status in one place." /><main className="section"><div className="container-wide">
    <div className="card card-pad" style={{ marginBottom: 16 }} data-testid="card-report-lookup"><div className="section-kicker">Track by reference</div><h2 className="section-title" style={{ fontSize: "1.25rem" }}>Have a report reference?</h2><div className="service-search" style={{ marginTop: 10 }}><Search size={17} /><input className="input" value={lookup} onChange={(e) => setLookup(e.target.value)} placeholder="Example: KD-2026-CD5678" aria-label="Report reference" data-testid="input-report-reference" /><Link href={matched ? `/reports/${matched.id}` : "/reports"} className="btn btn-primary btn-small" data-testid="button-track-reference">Track</Link></div>{lookup && !matched && <span className="form-help">No matching demo reference yet. Try <strong>KD-2026-CD5678</strong>.</span>}{matched && <span className="form-help">Found: {matched.category} · {matched.status.replace("_", " ")}</span>}</div>{isDemoSet && <div className="demo-caption" style={{ marginBottom: 14 }}><span>{DEMO_LABEL}</span> Showing prototype reports because no authenticated session was found. Sign in to see your real submissions.</div>}{reportsQuery.isLoading ? <Skeletons /> : <div className="card card-pad">{reports.length ? reports.map((report) => <ReportRow report={report} key={report.id} />) : <EmptyState icon={Flag} title="No reports yet" copy="When you report a local issue, it will appear here for easy tracking." />}</div>}<Link href="/report" className="btn btn-primary" style={{ marginTop: 18 }} data-testid="button-new-report"><Flag size={15} /> Report a new issue</Link></div></main></Layout>;
}

function ReportRow({ report }: { report: Report }) { return <div className="report-row" data-testid={`row-report-${report.id}`}><div><h3>{report.category}</h3><p>{report.location} · {dateLabel(report.createdAt)}</p></div><div style={{ display: "flex", alignItems: "center", gap: 9 }}><span className={`status-pill status-${report.status}`} data-testid={`status-report-${report.id}`}>{report.status.replace("_", " ")}</span><Link href={`/reports/${report.id}`} className="arrow-link" data-testid={`link-report-${report.id}`}><ChevronRight size={16} /></Link></div></div>; }

function ReportDetail() {
  const { id = "" } = useParams<{ id: string }>();
  const reportQuery = useGetReport(id, { query: { enabled: Boolean(id) && !DEMO_MODE, queryKey: getGetReportQueryKey(id) } });
  const demoStore = useDemoStore();
  const report = reportQuery.data || demoStore.findReport(id);
  const isDemoSet = !reportQuery.data;
  return <Layout><PageHeading kicker="Report detail" title={report ? report.category : "Report status"} description="A simple record of where your report is in the review journey." /><main className="section"><div className="container-wide">{reportQuery.isError && !report && <QueryError error={reportQuery.error} onRetry={() => reportQuery.refetch()} />}{reportQuery.isLoading && !report ? <Skeletons /> : report ? <div className="detail-grid"><div className="card card-pad">{isDemoSet && <div className="demo-caption" style={{ marginBottom: 14 }}><span>{DEMO_LABEL}</span> Prototype tracking record.</div>}<div style={{ display: "flex", justifyContent: "space-between", gap: 16, alignItems: "start" }}><div><div className="eyebrow">Report ID</div><div className="font-mono-civic" style={{ color: "hsl(var(--primary))", fontSize: "1.3rem", marginTop: 7 }}>{report.reportId}</div></div><span className={`status-pill status-${report.status}`} data-testid="status-report-detail">{report.status.replace("_", " ")}</span></div><div className="orbit-line" style={{ background: "hsl(var(--border))" }} /><p style={{ color: "hsl(var(--foreground))", lineHeight: 1.6, fontSize: ".88rem" }}>{report.description}</p><p className="form-help"><strong>Location:</strong> {report.location}<br /><strong>LGA:</strong> {report.lga}<br /><strong>Submitted:</strong> {dateLabel(report.createdAt)}<br /><strong>Last update:</strong> {dateLabel(report.updatedAt)}</p></div><div className="card timeline"><div className="eyebrow" style={{ marginBottom: 18 }}>Progress</div>{["submitted", "under_review", "in_progress", "resolved"].map((status, index, arr) => { const reached = arr.indexOf(report.status) >= index; return <div className="timeline-item" key={status}><strong>{status.replace("_", " ")}</strong><span>{status === report.status ? "Current status" : reached ? dateLabel(report.updatedAt) : "Next update will appear here"}</span></div>; })}<Link href="/report" className="btn btn-outline btn-small" style={{ marginTop: 16 }} data-testid="button-track-new-report">Report another issue</Link></div></div> : <><EmptyState title="Report not found" copy="Check the report ID or return to your reports." icon={CircleAlert} /><div style={{ marginTop: 16, textAlign: "center" }}><Link href="/reports" className="btn btn-primary" data-testid="button-view-reports">View reports <ArrowRight size={15} /></Link></div></>}</div></main></Layout>;
}

const aiSuggestedQuestions = [
  "How can I find scholarship opportunities?",
  "What government services are available?",
  "How can I report a community issue?",
  "Where can I find agricultural information?",
  "How can I find youth opportunities?",
  "How can I track my request?",
];

function matchServiceForQuestion(text: string): { label: string; category: string; href: string; action: string } | null {
  const q = text.toLowerCase();
  if (/scholarship|bursary|admission|jamb|waec|necos?|school/.test(q)) return { label: "Education", category: "Scholarships & admissions", href: "/education", action: "Open Education" };
  if (/report|issue|complain|road|water|electric|waste/.test(q)) return { label: "Report an Issue", category: "Civic reporting", href: "/report", action: "Report an Issue" };
  if (/track|status|reference|kd-/.test(q)) return { label: "Track a Request", category: "Report tracking", href: "/reports", action: "Track a Request" };
  if (/job|internship|training|youth|enterprise|entrepreneur|work/.test(q)) return { label: "Jobs & Skills", category: "Jobs, training & youth", href: "/jobs", action: "Open Jobs & Skills" };
  if (/farm|agricult|crop|market/.test(q)) return { label: "Agriculture", category: "Farming & markets", href: "/agriculture", action: "Open Agriculture" };
  if (/health|hospital|clinic|maternal/.test(q)) return { label: "Health", category: "Health services", href: "/health", action: "Open Health" };
  if (/government|ministry|agency|office/.test(q)) return { label: "Government", category: "Directory & information", href: "/government", action: "Open Government" };
  return null;
}

function buildDemoAssistantAnswer(question: string, language: "english" | "hausa"): AssistantAnswer {
  const relevant = matchServiceForQuestion(question);
  if (language === "hausa") {
    const hausaAnswer = relevant?.label === "Education"
      ? "A cikin wannan demo, za ka iya duba damar scholarship da bursary a sashen Education sannan ka buɗe bayanan da suka dace."
      : relevant?.label === "Report an Issue"
        ? "A cikin wannan demo, za ka iya kai rahoton matsalar hanya, ruwa, shara ko wani abin da ya shafi al'umma, sannan ka bibiyi reference number."
        : relevant?.label === "Jobs & Skills"
          ? "Za ka iya bincika ayyuka, internships, horo da damar matasa a sashen Jobs & Skills na wannan demo."
          : relevant?.label === "Agriculture"
            ? "Za ka iya duba bayanan noma, kasuwanni da damar tallafi a sashen Agriculture na wannan demo."
            : relevant?.label === "Health"
              ? "Za ka iya duba bayanan lafiya da tsarin directory na cibiyoyin lafiya a sashen Health na wannan demo."
              : relevant?.label === "Government"
                ? "Za ka iya bincika ministries, agencies da public offices a Government directory na wannan demo."
                : "Tambayar ta dace da tsarin Civic Digital. Gwada tambaya game da scholarship, jobs, agriculture, health, government services ko rahoton matsala.";
    return { answer: hausaAnswer, language, disclaimer: "Wannan amsa ce ta demo kawai; ba shawarar hukuma ba ce kuma ba ta haɗe da tsarin gwamnati kai tsaye." };
  }
  const answer = relevant?.label === "Education"
    ? "In this demo, you can browse scholarship and bursary opportunities in the Education service and open a listing for its eligibility, requirements and prototype application flow."
    : relevant?.label === "Report an Issue"
      ? "In this demo, you can report a community issue such as roads, water, waste or electricity, receive a reference number and track the request journey."
      : relevant?.label === "Jobs & Skills"
        ? "Browse jobs, internships, training and youth opportunities in the Jobs & Skills service."
        : relevant?.label === "Agriculture"
          ? "Explore farming information, market resources and agricultural opportunities in the Agriculture service."
          : relevant?.label === "Health"
            ? "Explore health information, facilities and public-health resources in the Health service."
            : relevant?.label === "Government"
              ? "Use the Government directory to explore illustrative ministries, agencies and public offices."
              : "This prototype can help you find Education, Jobs & Skills, Agriculture, Health, Government information and civic reporting routes. Try one of those topics.";
  return { answer, language, disclaimer: "Demo response only. This prototype is not an official government source and is not connected to live government systems." };
}

function AiPage() {
  const ask = useAskAssistant();
  const initialQuestion = new URLSearchParams(window.location.search).get("q") || "";
  const [question, setQuestion] = useState(initialQuestion);
  const [language, setLanguage] = useState<"english" | "hausa">("english");
  const [answer, setAnswer] = useState<AssistantAnswer | null>(null);
  const [askedQuestion, setAskedQuestion] = useState("");
  const runAsk = (q: string) => { if (q.trim().length < 2) return; const clean = q.trim(); setAskedQuestion(clean); if (DEMO_MODE) { setAnswer(buildDemoAssistantAnswer(clean, language)); return; } ask.mutate({ data: { question: clean, language } }, { onSuccess: (data) => setAnswer(data) }); };
  const submit = (event: FormEvent) => { event.preventDefault(); runAsk(question); };
  const relevant = answer ? matchServiceForQuestion(askedQuestion) : null;
  useEffect(() => { if (initialQuestion) runAsk(initialQuestion); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  return <Layout><PageHeading kicker="Katsina AI" title="Ask a clearer question." description="A bilingual assistant concept for finding public information in Hausa or English. It is prepared for a future AI service and clearly labels its limits." /><main className="section"><div className="container-wide assistant-layout"><div className="notice"><strong>Prototype boundary.</strong> Do not share passwords, private records or urgent medical or safety situations. For urgent help, use the relevant local emergency route.</div><div className="card assistant-window"><div className="chat-messages"><div className="chat-message bot" data-testid="text-ai-welcome">Sannu. I’m the Katsina AI concept. Ask me about education, jobs, agriculture, health or government information.</div>{!answer && !ask.isPending && <div className="ai-suggestions" style={{ margin: "4px 0 2px" }}>{aiSuggestedQuestions.map((sq) => <a key={sq} onClick={() => { setQuestion(sq); runAsk(sq); }} data-testid={`button-ai-suggestion-${sq.slice(0, 12).replace(/\s+/g, "-").toLowerCase()}`}>{sq}</a>)}</div>}{answer && <div className="chat-message user" data-testid="text-ai-answer"><div className="eyebrow" style={{ marginBottom: 4, opacity: .75 }}>Answer</div>{answer.answer}<div style={{ marginTop: 10, paddingTop: 9, borderTop: "1px solid hsl(var(--primary-foreground) / .18)", fontSize: ".68rem", opacity: .7 }}>{answer.disclaimer}</div>{relevant && <div style={{ marginTop: 12, paddingTop: 10, borderTop: "1px solid hsl(var(--primary-foreground) / .18)", display: "grid", gap: 4, fontSize: ".72rem" }}><span><strong>Relevant service:</strong> {relevant.label}</span><span><strong>Category:</strong> {relevant.category}</span><span><strong>Next action:</strong> {relevant.action}</span><Link href={relevant.href} className="btn btn-gold btn-small" style={{ marginTop: 6, width: "fit-content" }} data-testid="button-ai-open-service">{relevant.action} <ArrowRight size={13} /></Link></div>}</div>}{ask.isError && <div className="error-box" data-testid="status-ai-error">The assistant could not answer right now. Please try again.</div>}</div><form className="chat-compose" onSubmit={submit}><select className="select" style={{ width: 120 }} value={language} onChange={(event) => setLanguage(event.target.value as "english" | "hausa")} aria-label="Assistant language" data-testid="select-ai-language"><option value="english">English</option><option value="hausa">Hausa</option></select><input className="input" value={question} onChange={(event) => setQuestion(event.target.value)} placeholder="What would you like to find?" aria-label="Ask Katsina AI" data-testid="input-ai-question" /><button className="btn btn-primary" type="submit" disabled={ask.isPending || question.trim().length < 2} data-testid="button-ask-ai">{ask.isPending ? "Thinking…" : "Ask"} <ArrowRight size={15} /></button></form></div><div className="grid-3"><div className="card card-pad"><ShieldCheck size={19} color="hsl(var(--accent))" /><h3 style={{ color: "hsl(var(--primary))", fontSize: ".9rem", margin: "12px 0 4px" }}>Grounded, not authoritative</h3><p className="form-help">Answers should point you toward useful public information, not make decisions for you.</p></div><div className="card card-pad"><MessageCircle size={19} color="hsl(var(--accent))" /><h3 style={{ color: "hsl(var(--primary))", fontSize: ".9rem", margin: "12px 0 4px" }}>Hausa and English</h3><p className="form-help">Choose the language that makes the question easiest to ask.</p></div><div className="card card-pad"><Landmark size={19} color="hsl(var(--accent))" /><h3 style={{ color: "hsl(var(--primary))", fontSize: ".9rem", margin: "12px 0 4px" }}>Built for local context</h3><p className="form-help">The first pilot focuses on Katsina LGA within the wider Katsina State concept.</p></div></div></div></main></Layout>;
}

function DashboardShell({ children, title, subtitle }: { children: ReactNode; title: string; subtitle: string }) {
  const [location] = useLocation();
  return <Layout><main className="container-wide dashboard-layout"><aside className="dashboard-sidebar"><Brand light /><div className="side-nav" style={{ marginTop: 28 }}>{[{ href: "/dashboard", label: "Overview", icon: Building2 }, { href: "/reports", label: "My reports", icon: Flag }, { href: "/notifications", label: "Notifications", icon: Bell }, { href: "/saved", label: "Saved items", icon: CheckCircle2 }, { href: "/profile", label: "Profile", icon: UserRound }, { href: "/ai", label: "Katsina AI", icon: Sparkles }].map(({ href, label, icon: Icon }) => <Link href={href} className={cx(location === href && "active")} key={href} data-testid={`link-sidebar-${label.toLowerCase().replaceAll(" ", "-")}`}><Icon size={15} /> {label}</Link>)}</div><Link href="/report" className="btn btn-gold btn-small" style={{ marginTop: 28 }} data-testid="button-sidebar-report"><Flag size={14} /> New report</Link></aside><section className="dashboard-main"><h1 className="dash-title">{title}</h1><p className="dash-sub">{subtitle}</p>{children}</section></main></Layout>;
}

function DashboardPage() {
  const summaryQuery = useGetDashboardSummary({ query: { enabled: !DEMO_MODE } });
  const userQuery = useGetCurrentUser({ query: { enabled: !DEMO_MODE } });
  const demoStore = useDemoStore();
  const isDemoSet = !summaryQuery.data;
  const demoActive = demoStore.reports.filter((r) => r.status !== "resolved").length;
  const summary = summaryQuery.data ?? { reportCount: demoStore.reports.length, activeReportCount: demoActive, savedCount: demoStore.savedItemIds.length, notifications: demoStore.notifications.filter((n) => !n.read).length, recentReports: demoStore.reports.slice(0, 3) };
  const displayName = userQuery.data?.name || demoUser.name;
  return <DashboardShell title={`Good to see you, ${displayName.split(" ")[0]}.`} subtitle="Your latest activity and useful next steps.">{isDemoSet && <div className="demo-caption" style={{ marginBottom: 14 }}><span>{DEMO_LABEL}</span> No authenticated session was found, so figures below reflect this prototype's demo tracker.</div>}<div className="metric-grid">{[{ label: "All reports", value: summary.reportCount ?? 0, icon: Flag, href: "/reports" }, { label: "Active reports", value: summary.activeReportCount ?? 0, icon: CircleAlert, href: "/reports" }, { label: "Saved items", value: summary.savedCount ?? 0, icon: CheckCircle2, href: "/saved" }, { label: "Notifications", value: summary.notifications ?? 0, icon: Bell, href: "/notifications" }].map(({ label, value, icon: Icon, href }) => <Link href={href} className="card metric-card card-hover" key={label} data-testid={`metric-${label.toLowerCase().replaceAll(" ", "-")}`}><Icon className="icon" size={18} /><span className="metric-value">{value}</span><span className="metric-label">{label}</span></Link>)}</div>{summaryQuery.isError && !DEMO_MODE && <QueryError error={summaryQuery.error} onRetry={() => summaryQuery.refetch()} />}<div className="card card-pad"><div className="section-head" style={{ marginBottom: 9 }}><div><div className="section-kicker">Activity</div><h2 className="section-title" style={{ fontSize: "1.5rem" }}>Recent reports</h2></div><Link href="/reports" className="arrow-link" data-testid="link-dashboard-reports">See all <ChevronRight size={15} /></Link></div>{summaryQuery.isLoading ? <Skeletons /> : summary.recentReports?.length ? summary.recentReports.map((report) => <ReportRow key={report.id} report={report} />) : <EmptyState icon={Flag} title="Your activity starts here" copy="Submit an issue or explore the service routes to make this space useful." />}</div><div className="card card-pad" style={{ marginTop: 16 }}><div className="section-head" style={{ marginBottom: 9 }}><div><div className="section-kicker">Issue categories</div><h2 className="section-title" style={{ fontSize: "1.3rem" }}>What's being reported</h2></div></div><div className="resource-list">{Array.from(new Set(demoStore.reports.map((r) => r.category))).map((category) => <div className="resource-item" key={category}><Flag size={14} color="hsl(var(--accent))" /><span><strong>{category}</strong><span>{demoStore.reports.filter((r) => r.category === category).length} report(s)</span></span></div>)}</div></div></DashboardShell>;
}

function ProfilePage() {
  const userQuery = useGetCurrentUser({ query: { enabled: !DEMO_MODE } });
  const isDemoSet = !userQuery.data;
  const user = userQuery.data ?? demoUser;
  return <DashboardShell title="Your profile." subtitle="The basics that help keep your Katsina Digital experience personal.">{isDemoSet && <div className="demo-caption" style={{ marginBottom: 14 }}><span>{DEMO_LABEL}</span> Showing a demo profile because no authenticated session was found.</div>}<div className="card card-pad profile-card"><div className="avatar" data-testid="text-profile-initials">{initials(user?.name)}</div><div><div className="eyebrow">Citizen profile</div><h2 style={{ margin: "7px 0 5px", color: "hsl(var(--primary))", fontSize: "1.35rem" }} data-testid="text-profile-name">{user?.name || "Your name"}</h2><p className="form-help" data-testid="text-profile-email">{user?.email || "Your email will appear here after sign in."}</p></div></div><div className="card card-pad" style={{ marginTop: 14 }}><div className="section-kicker">Account details</div><div className="resource-list" style={{ marginTop: 12 }}><div className="resource-item"><UserRound size={16} color="hsl(var(--accent))" /><span><strong>Role</strong><span>{user?.role || "citizen"}</span></span></div><div className="resource-item"><Building2 size={16} color="hsl(var(--accent))" /><span><strong>Joined</strong><span>{dateLabel(user?.joinedAt)}</span></span></div><div className="resource-item"><MessageCircle size={16} color="hsl(var(--accent))" /><span><strong>Phone</strong><span>{user?.phone || "Not added"}</span></span></div></div></div><div className="grid-2" style={{ marginTop: 16 }}><Link href="/reports" className="card card-pad card-hover" data-testid="link-profile-reports"><Flag size={16} color="hsl(var(--accent))" /><h3 style={{ color: "hsl(var(--primary))", fontSize: ".9rem", margin: "10px 0 4px" }}>My reports</h3><p className="form-help">View and track submitted reports.</p></Link><Link href="/saved" className="card card-pad card-hover" data-testid="link-profile-saved"><CheckCircle2 size={16} color="hsl(var(--accent))" /><h3 style={{ color: "hsl(var(--primary))", fontSize: ".9rem", margin: "10px 0 4px" }}>Saved items</h3><p className="form-help">Opportunities and resources you bookmarked.</p></Link></div></DashboardShell>;
}

type AdminPanel = "users" | "lgas" | "jobs" | "schools" | "health-agri";
const adminPanels: { id: AdminPanel; label: string }[] = [
  { id: "users", label: "Users and roles" },
  { id: "lgas", label: "LGAs and pilot areas" },
  { id: "jobs", label: "Jobs and scholarships" },
  { id: "schools", label: "Schools and government information" },
  { id: "health-agri", label: "Health facilities and agriculture resources" },
];

function AdminPanelView({ panel }: { panel: AdminPanel }) {
  const lgas = useListLgas({ query: { enabled: !DEMO_MODE } });
  if (panel === "users") return <div className="resource-list" style={{ marginTop: 13 }}>{demoAdminUsers.map((u) => <div className="resource-item" key={u.id} data-testid={`admin-row-user-${u.id}`}><UserRound size={15} color="hsl(var(--accent))" /><span><strong>{u.name}</strong><span>{u.email} · {u.role}</span></span><span className="tag" style={{ marginLeft: "auto" }}>{u.status}</span></div>)}</div>;
  if (panel === "lgas") return <div className="resource-list" style={{ marginTop: 13, maxHeight: 320, overflowY: "auto" }}>{(lgas.data?.length ? lgas.data : fallbackLgas).map((lga) => <div className="resource-item" key={lga.id} data-testid={`admin-row-lga-${lga.id}`}><Landmark size={15} color="hsl(var(--accent))" /><span><strong>{lga.name}</strong><span>{lga.description}</span></span>{lga.isPilot && <span className="tag tag-gold" style={{ marginLeft: "auto" }}>Pilot</span>}</div>)}</div>;
  if (panel === "jobs") return <div className="resource-list" style={{ marginTop: 13 }}>{fallbackOpportunities.map((opp) => <Link href={`/opportunities/${opp.id}`} className="resource-item" key={opp.id} data-testid={`admin-row-opportunity-${opp.id}`}><BriefcaseBusiness size={15} color="hsl(var(--accent))" /><span><strong>{opp.title}</strong><span>{opp.type} · {opp.status}</span></span><ChevronRight size={14} style={{ marginLeft: "auto" }} /></Link>)}</div>;
  if (panel === "schools") return <div className="resource-list" style={{ marginTop: 13 }}>{demoGovernmentDirectory.map((entry) => <Link href={`/government/${entry.id}`} className="resource-item" key={entry.id} data-testid={`admin-row-government-${entry.id}`}><Building2 size={15} color="hsl(var(--accent))" /><span><strong>{entry.name}</strong><span>{entry.category}</span></span><ChevronRight size={14} style={{ marginLeft: "auto" }} /></Link>)}</div>;
  return <div className="resource-list" style={{ marginTop: 13 }}>{fallbackResources.filter((r) => r.domain === "health" || r.domain === "agriculture").map((res) => <Link href={`/resources/${res.id}`} className="resource-item" key={res.id} data-testid={`admin-row-resource-${res.id}`}><FileText size={15} color="hsl(var(--accent))" /><span><strong>{res.title}</strong><span>{res.domain}</span></span><ChevronRight size={14} style={{ marginLeft: "auto" }} /></Link>)}</div>;
}

function AdminPage() {
  const overview = useGetAdminOverview({ query: { enabled: !DEMO_MODE } });
  const demoStore = useDemoStore();
  const data = overview.data;
  const isDemoSet = !overview.data;
  const items = [{ label: "Users", value: data?.users ?? demoAdminUsers.length, icon: UserRound }, { label: "Citizen reports", value: data?.reports ?? demoStore.reports.length, icon: Flag }, { label: "Opportunities", value: data?.opportunities ?? fallbackOpportunities.length, icon: BriefcaseBusiness }, { label: "Resources", value: data?.resources ?? fallbackResources.length, icon: FileText }, { label: "LGAs", value: data?.lgas ?? fallbackLgas.length, icon: Landmark }];
  const [openPanel, setOpenPanel] = useState<AdminPanel | null>(null);
  return <DashboardShell title="Pilot control room." subtitle="A compact view for authorized administrators managing the Katsina LGA pilot."><div className="notice" style={{ marginBottom: 18 }}><strong>Admin access is role-based.</strong> This view is designed for authorized administrators; demo data is clearly marked before publishing.</div>{isDemoSet && <div className="demo-caption" style={{ marginBottom: 18 }}><span>{DEMO_LABEL}</span> Showing prototype figures because no authenticated admin session was found.</div>}<div className="admin-kpi">{items.map(({ label, value, icon: Icon }) => <div className="card metric-card" key={label} data-testid={`admin-metric-${label.toLowerCase().replaceAll(" ", "-")}`}><span><span className="metric-value" style={{ marginTop: 0 }}>{value}</span><span className="metric-label">{label}</span></span><Icon size={20} color="hsl(var(--accent))" /></div>)}</div><div className="grid-2" style={{ marginTop: 18 }}><div className="card card-pad"><div className="section-kicker">Manage</div><h2 className="section-title" style={{ fontSize: "1.5rem" }}>Pilot content</h2><div className="resource-list" style={{ marginTop: 13 }}>{adminPanels.map(({ id, label }) => <button className="resource-item" style={{ border: 0, textAlign: "left", cursor: "pointer", background: openPanel === id ? "hsl(var(--secondary))" : undefined }} key={id} onClick={() => setOpenPanel(openPanel === id ? null : id)} data-testid={`button-admin-${id}`}><Building2 size={16} color="hsl(var(--accent))" /><span><strong>{label}</strong><span>{openPanel === id ? "Showing demo records below" : "Open management surface"}</span></span><ChevronRight size={15} style={{ marginLeft: "auto", transform: openPanel === id ? "rotate(90deg)" : undefined }} /></button>)}</div>{openPanel && <AdminPanelView panel={openPanel} />}</div><div className="card card-pad"><div className="section-kicker">Announcements</div><h2 className="section-title" style={{ fontSize: "1.5rem" }}>Demo publishing checklist</h2><div className="resource-list" style={{ marginTop: 13 }}>{["Confirm source label", "Select pilot LGA", "Review Hausa / English copy", "Publish announcement"].map((label, index) => <div className="resource-item" key={label}><span className="resource-dot" style={{ background: index < 2 ? "hsl(var(--accent))" : "hsl(var(--border))" }} /><span><strong>{label}</strong><span>{index < 2 ? "Ready for review" : "Awaiting content"}</span></span></div>)}</div><div className="eyebrow" style={{ marginTop: 20 }}>Recent announcements</div><div className="resource-list" style={{ marginTop: 10 }}>{demoNews.slice(0, 3).map((n) => <Link href={`/news/${n.id}`} className="resource-item" key={n.id} data-testid={`admin-row-news-${n.id}`}><FileText size={14} color="hsl(var(--accent))" /><span><strong>{n.title}</strong><span>{dateLabel(n.date)}</span></span><ChevronRight size={14} style={{ marginLeft: "auto" }} /></Link>)}</div></div></div></DashboardShell>;
}

function SearchPage() {
  const initialQuery = new URLSearchParams(window.location.search).get("q") || "";
  const [query, setQuery] = useState(initialQuery);
  const index = useMemo(() => buildSearchIndex(), []);
  const q = query.trim().toLowerCase();
  const results = q ? index.filter((item) => `${item.title} ${item.summary} ${item.tag}`.toLowerCase().includes(q)) : index;
  const kindIcon: Record<string, typeof FileText> = { opportunity: BriefcaseBusiness, resource: FileText, government: Landmark, news: Newspaper, service: Search };
  return <Layout><PageHeading kicker="Search" title="Find a service, opportunity or resource." description="Search across services, opportunities, resources, government directory entries and news." /><main className="section"><div className="container-wide">
    <div className="service-search" style={{ marginBottom: 10 }}><Search size={18} aria-hidden="true" /><input aria-label="Search everything" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Try scholarship, jobs, training, agriculture, health, roads, water…" data-testid="input-global-search" />{query && <button className="search-clear" onClick={() => setQuery("")} aria-label="Clear search" data-testid="button-clear-search"><X size={16} /></button>}</div>
    <div className="search-meta" style={{ marginBottom: 18 }}>{q ? `${results.length} results found` : "Search by service, category or keyword"}</div>
    {results.length ? <div className="opportunity-grid">{results.map((item) => { const Icon = kindIcon[item.kind]; return <Link href={item.href} className="card card-pad card-hover" key={`${item.kind}-${item.id}`} data-testid={`card-search-${item.kind}-${item.id}`}><span className="tag">{item.tag}</span><h3 style={{ color: "hsl(var(--primary))", margin: "12px 0 6px", fontSize: ".95rem", display: "flex", alignItems: "center", gap: 7 }}><Icon size={15} color="hsl(var(--accent))" /> {item.title}</h3><p style={{ color: "hsl(var(--muted-foreground))", fontSize: ".8rem", lineHeight: 1.55 }}>{item.summary}</p></Link>; })}</div> : <div className="empty-state service-empty" data-testid="empty-search"><Search size={26} /><strong>No results for “{query}”</strong><span>Try a different phrase, or use one of the suggestions below.</span><div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "center", marginTop: 14 }}><button className="btn btn-outline btn-small" onClick={() => setQuery("")} data-testid="button-search-clear-all">Clear search</button><Link href="/government" className="btn btn-outline btn-small" data-testid="button-search-view-all">View all services</Link></div><div style={{ marginTop: 16 }}><div className="form-help" style={{ marginBottom: 8 }}>Suggested searches</div><div style={{ display: "flex", gap: 7, flexWrap: "wrap", justifyContent: "center" }}>{suggestedSearches.map((term) => <button key={term} className="tag" style={{ cursor: "pointer", border: "none" }} onClick={() => setQuery(term)} data-testid={`button-suggested-${term}`}>{term}</button>)}</div></div></div>}
  </div></main></Layout>;
}

function NotificationsPage() {
  const { notifications } = useDemoStore();
  return <DashboardShell title="Notifications." subtitle="Demo notifications generated from your prototype activity."><div className="card card-pad"><div className="demo-caption" style={{ marginBottom: 14 }}><span>{DEMO_LABEL}</span> These notifications are illustrative and not connected to a live messaging system.</div>{notifications.length ? <div className="resource-list">{notifications.map((item) => <div className="resource-item" key={item.id} data-testid={`row-notification-${item.id}`}><Bell size={15} color="hsl(var(--accent))" /><span><strong>{item.title}</strong><span>{item.body}</span></span><span className="form-help" style={{ marginLeft: "auto", whiteSpace: "nowrap" }}>{dateLabel(item.date)}</span></div>)}</div> : <EmptyState icon={Bell} title="No notifications yet" copy="Updates about your reports and opportunities will appear here." />}</div></DashboardShell>;
}

function SavedPage() {
  const { savedItemIds } = useDemoStore();
  const items = savedItemIds.map((id) => fallbackResources.find((r) => r.id === id) || fallbackOpportunities.find((o) => o.id === id) || demoGovernmentDirectory.find((g) => g.id === id)).filter(Boolean) as Array<{ id: string; title?: string; name?: string }>;
  return <DashboardShell title="Saved items." subtitle="A demo list of resources and opportunities you have bookmarked."><div className="card card-pad">{items.length ? <div className="resource-list">{items.map((item: any) => <Link href={item.organization ? `/opportunities/${item.id}` : item.name ? `/government/${item.id}` : `/resources/${item.id}`} className="resource-item" key={item.id} data-testid={`row-saved-${item.id}`}><CheckCircle2 size={15} color="hsl(var(--accent))" /><span><strong>{item.title || item.name}</strong></span><ChevronRight size={14} style={{ marginLeft: "auto" }} /></Link>)}</div> : <EmptyState icon={CheckCircle2} title="Nothing saved yet" copy="Bookmark opportunities and resources to find them here." />}</div></DashboardShell>;
}

function AuthPage({ signUp = false }: { signUp?: boolean }) {
  if (clerkPubKey) return <div className="auth-page"><div style={{ width: "min(460px, 100%)" }}>{signUp ? <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} /> : <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} />}</div></div>;
  return <div className="auth-page"><div className="auth-card"><Brand light={false} /><h1>{signUp ? "Create your account." : "Welcome back."}</h1><p>{signUp ? "A branded Clerk account screen will appear here once authentication is provisioned for this environment." : "Sign in to track reports, save useful information and use your personal dashboard."}</p><div className="notice" style={{ margin: "20px 0" }}>Authentication is ready for Clerk’s cookie-based web flow. No browser token handling is used.</div><Link href="/" className="btn btn-primary" data-testid="button-auth-home">Return to homepage <ArrowRight size={15} /></Link><div style={{ marginTop: 14 }}><Link href={signUp ? "/sign-in" : "/sign-up"} className="arrow-link" data-testid="link-auth-switch">{signUp ? "Already have an account? Sign in" : "Need an account? Sign up"} <ChevronRight size={14} /></Link></div></div></div>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) { const [location] = useLocation(); return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>; }

function Router() {
  return <RoutedErrorBoundary><Switch>
    <Route path="/" component={Home} />
    <Route path="/education" component={() => <CatalogPage domain="education" />} />
    <Route path="/jobs" component={() => <CatalogPage domain="jobs" />} />
    <Route path="/opportunities" component={() => <CatalogPage domain="jobs" />} />
    <Route path="/agriculture" component={() => <CatalogPage domain="agriculture" />} />
    <Route path="/health" component={() => <CatalogPage domain="health" />} />
    <Route path="/government" component={() => <CatalogPage domain="government" />} />
    <Route path="/opportunities/:id" component={OpportunityDetail} />
    <Route path="/resources/:id" component={InfoDetail} />
    <Route path="/government/:id" component={InfoDetail} />
    <Route path="/lga/:id" component={LgaDetail} />
    <Route path="/news/:id" component={InfoDetail} />
    <Route path="/search" component={SearchPage} />
    <Route path="/notifications" component={NotificationsPage} />
    <Route path="/saved" component={SavedPage} />
    <Route path="/report" component={ReportPage} />
    <Route path="/reports" component={ReportsPage} />
    <Route path="/reports/:id" component={ReportDetail} />
    <Route path="/ai" component={AiPage} />
    <Route path="/dashboard" component={DashboardPage} />
    <Route path="/profile" component={ProfilePage} />
    <Route path="/admin" component={AdminPage} />
    <Route path="/sign-in/*?" component={() => <AuthPage />} />
    <Route path="/sign-up/*?" component={() => <AuthPage signUp />} />
    <Route component={NotFound} />
  </Switch></RoutedErrorBoundary>;
}

function ApplyFlow({ opportunity }: { opportunity: DemoOpportunity }) {
  const [step, setStep] = useState<0 | 1 | 2 | 3 | 4>(0);
  const [form, setForm] = useState({ name: demoUser.name, email: demoUser.email, phone: demoUser.phone, lga: "Musawa", dateOfBirth: "", education: "" });
  const [requirementValues, setRequirementValues] = useState<Record<string, string | boolean>>({});
  const [applicationRef, setApplicationRef] = useState("");
  const update = (key: keyof typeof form, value: string) => setForm((current) => ({ ...current, [key]: value }));
  const updateRequirement = (requirement: string, value: string | boolean) => setRequirementValues((current) => ({ ...current, [requirement]: value }));
  const requirements = opportunity.requirements || [];
  const canContinue = Boolean(form.name.trim() && form.email.trim() && form.phone.trim() && form.lga.trim());

  const requirementKind = (requirement: string) => {
    if (/guardian consent|consent/i.test(requirement)) return "checkbox" as const;
    if (/statement|cover note|business summary|application letter|short note/i.test(requirement)) return "textarea" as const;
    if (/result|certificate|transcript|cv|curriculum vitae|credentials|admission|student id|letter|document|proof/i.test(requirement)) return "file" as const;
    if (/literacy|language/i.test(requirement)) return "select" as const;
    return "text" as const;
  };

  const requirementComplete = (requirement: string) => {
    const value = requirementValues[requirement];
    return typeof value === "boolean" ? value : Boolean(String(value || "").trim());
  };

  if (step === 0) return <button className="btn btn-gold" onClick={() => setStep(1)} data-testid="button-opportunity-apply">Apply <ArrowRight size={15} /></button>;
  return <div className="card card-pad" style={{ marginTop: 16 }} data-testid="panel-apply-flow">
    <div className="notice" style={{ marginBottom: 16 }}><strong>PROTOTYPE APPLICATION.</strong> This demonstration shows how an application process could work. Nothing is submitted to a government agency or external organisation.</div>
    {step === 1 && <>
      <div className="section-kicker">Step 1 of 3 · Applicant details</div>
      <div className="form-grid" style={{ marginTop: 14 }}>
        <div className="form-field"><label className="label" htmlFor="apply-name">Full name</label><input id="apply-name" className="input" value={form.name} onChange={(e) => update("name", e.target.value)} required data-testid="input-apply-name" /></div>
        <div className="form-field"><label className="label" htmlFor="apply-email">Email</label><input id="apply-email" type="email" className="input" value={form.email} onChange={(e) => update("email", e.target.value)} required data-testid="input-apply-email" /></div>
        <div className="form-field"><label className="label" htmlFor="apply-phone">Phone number</label><input id="apply-phone" className="input" value={form.phone} onChange={(e) => update("phone", e.target.value)} required data-testid="input-apply-phone" /></div>
        <div className="form-field"><label className="label" htmlFor="apply-lga">LGA</label><input id="apply-lga" className="input" value={form.lga} onChange={(e) => update("lga", e.target.value)} required data-testid="input-apply-lga" /></div>
        <div className="form-field"><label className="label" htmlFor="apply-dob">Date of birth <span className="form-help">(if relevant)</span></label><input id="apply-dob" type="date" className="input" value={form.dateOfBirth} onChange={(e) => update("dateOfBirth", e.target.value)} data-testid="input-apply-dob" /></div>
        <div className="form-field"><label className="label" htmlFor="apply-education">School / qualification <span className="form-help">(if relevant)</span></label><input id="apply-education" className="input" value={form.education} onChange={(e) => update("education", e.target.value)} placeholder="School, course or qualification" data-testid="input-apply-education" /></div>
      </div>
      <div style={{ display: "flex", gap: 9, marginTop: 18 }}><button className="btn btn-primary" disabled={!canContinue} onClick={() => setStep(2)} data-testid="button-apply-continue">Continue <ArrowRight size={15} /></button><button className="btn btn-outline" onClick={() => setStep(0)} data-testid="button-apply-cancel">Cancel</button></div>
    </>}
    {step === 2 && <>
      <div className="section-kicker">Step 2 of 3 · Complete requirements</div>
      <p className="form-help" style={{ marginTop: 6 }}>Each requirement listed for this opportunity has a matching demo field below. In a live service, these would be validated and securely stored.</p>
      <div className="card" style={{ padding: 14, marginTop: 14, background: "hsl(var(--secondary))" }}>
        <div className="eyebrow">Requirements for this listing</div>
        <div className="resource-list" style={{ marginTop: 8 }}>
          {requirements.map((requirement, index) => {
            const kind = requirementKind(requirement);
            return <div className="form-field" key={requirement} style={{ marginBottom: index === requirements.length - 1 ? 0 : 14 }}>
              <label className="label" htmlFor={`apply-requirement-${index}`}>{requirement} <span aria-hidden="true">*</span></label>
              {kind === "checkbox" ? <label style={{ display: "flex", gap: 9, alignItems: "flex-start", fontSize: ".82rem" }}><input id={`apply-requirement-${index}`} type="checkbox" checked={Boolean(requirementValues[requirement])} onChange={(e) => updateRequirement(requirement, e.target.checked)} data-testid={`checkbox-apply-requirement-${index}`} /><span>I confirm this requirement is represented in this prototype application.</span></label>
                : kind === "textarea" ? <textarea id={`apply-requirement-${index}`} className="textarea" value={String(requirementValues[requirement] || "")} onChange={(e) => updateRequirement(requirement, e.target.value)} placeholder={`Enter ${requirement.toLowerCase()} for the demo`} data-testid={`textarea-apply-requirement-${index}`} />
                  : kind === "file" ? <input id={`apply-requirement-${index}`} type="file" className="input" onChange={(e) => updateRequirement(requirement, Array.from(e.target.files || []).map((file) => file.name).join(", "))} data-testid={`input-file-apply-requirement-${index}`} />
                    : kind === "select" ? <select id={`apply-requirement-${index}`} className="select" value={String(requirementValues[requirement] || "")} onChange={(e) => updateRequirement(requirement, e.target.value)} data-testid={`select-apply-requirement-${index}`}><option value="">Select language</option><option value="Hausa">Hausa</option><option value="English">English</option><option value="Hausa and English">Hausa and English</option></select>
                      : <input id={`apply-requirement-${index}`} className="input" value={String(requirementValues[requirement] || "")} onChange={(e) => updateRequirement(requirement, e.target.value)} placeholder={`Enter ${requirement.toLowerCase()} for the demo`} data-testid={`input-apply-requirement-${index}`} />}
              <span className="form-help">Demo field only. Do not upload or enter sensitive real documents.</span>
            </div>;
          })}
        </div>
      </div>
      <div style={{ display: "flex", gap: 9, marginTop: 18 }}><button className="btn btn-primary" disabled={requirements.some((requirement) => !requirementComplete(requirement))} onClick={() => setStep(3)} data-testid="button-apply-review">Review application <ArrowRight size={15} /></button><button className="btn btn-outline" onClick={() => setStep(1)} data-testid="button-apply-back">Back</button></div>
    </>}
    {step === 3 && <>
      <div className="section-kicker">Step 3 of 3 · Review & submit demo</div>
      <div className="resource-list" style={{ marginTop: 14 }}>
        <div className="resource-item"><UserRound size={15} color="hsl(var(--accent))" /><span><strong>Name</strong><span>{form.name}</span></span></div>
        <div className="resource-item"><MessageCircle size={15} color="hsl(var(--accent))" /><span><strong>Email / phone</strong><span>{form.email} · {form.phone}</span></span></div>
        <div className="resource-item"><Landmark size={15} color="hsl(var(--accent))" /><span><strong>LGA</strong><span>{form.lga}</span></span></div>
        <div className="resource-item"><BriefcaseBusiness size={15} color="hsl(var(--accent))" /><span><strong>Applying for</strong><span>{opportunity.title}</span></span></div>
        <div className="resource-item"><FileText size={15} color="hsl(var(--accent))" /><span><strong>Requirements</strong><span>{requirements.filter(requirementComplete).length} of {requirements.length} completed</span></span></div>
      </div>
      <div className="notice" style={{ marginTop: 14 }}>All requirements above are represented in this demo. Supporting files are not uploaded or stored.</div>
      <div style={{ display: "flex", gap: 9, marginTop: 18 }}><button className="btn btn-primary" onClick={() => { setApplicationRef(`KCD-APP-${Date.now().toString().slice(-8)}`); setStep(4); }} data-testid="button-apply-submit">Submit prototype application <ArrowRight size={15} /></button><button className="btn btn-outline" onClick={() => setStep(2)} data-testid="button-apply-back-requirements">Back</button></div>
    </>}
    {step === 4 && <div className="success-box" data-testid="success-apply"><CheckCircle2 size={18} style={{ verticalAlign: "middle", marginRight: 6 }} /> Prototype application recorded for {form.name}. Reference: <strong>{applicationRef}</strong>. This is demo data only; no real application was submitted. A live deployment would validate the requirements, securely store documents and issue a real reference number.</div>}
  </div>;
}
function OpportunityDetail() {
  const { id = "" } = useParams<{ id: string }>();
  const query = useGetHomeOverview({ query: { enabled: !DEMO_MODE } });
  const opportunity = useMemo(() => query.data?.featuredOpportunities?.find((item) => item.id === id) as DemoOpportunity | undefined || fallbackOpportunities.find((item) => item.id === id), [query.data, id]);
  const related = useMemo(() => (opportunity?.relatedIds || []).map((relId) => fallbackOpportunities.find((item) => item.id === relId)).filter(Boolean) as DemoOpportunity[], [opportunity]);
  return <Layout><PageHeading kicker="Opportunity detail" title={opportunity?.title || "Opportunity"} description="A clearer view of eligibility, requirements, the application process and next step." /><main className="section"><div className="container-wide">{opportunity ? <div className="detail-grid"><div className="card card-pad"><span className="tag tag-gold">{opportunity.type}</span> <span className="tag">{DEMO_LABEL}</span><h2 style={{ color: "hsl(var(--primary))", fontSize: "1.8rem", letterSpacing: "-.05em", margin: "16px 0 7px" }}>{opportunity.title}</h2><p className="opportunity-meta">{opportunity.organization} · {opportunity.lga}</p><p style={{ lineHeight: 1.7, fontSize: ".88rem", marginTop: 24 }}>{opportunity.description}</p>
    {opportunity.eligibility && <><div className="section-kicker" style={{ marginTop: 22 }}>Who can apply</div><p style={{ fontSize: ".85rem", lineHeight: 1.6, marginTop: 6 }}>{opportunity.eligibility}</p></>}
    {opportunity.requirements?.length ? <><div className="section-kicker" style={{ marginTop: 18 }}>Requirements</div><ul style={{ marginTop: 8, paddingLeft: 18, fontSize: ".85rem", lineHeight: 1.7 }}>{opportunity.requirements.map((req) => <li key={req}>{req}</li>)}</ul></> : null}
    {opportunity.process?.length ? <><div className="section-kicker" style={{ marginTop: 18 }}>Application process</div><ol style={{ marginTop: 8, paddingLeft: 18, fontSize: ".85rem", lineHeight: 1.7 }}>{opportunity.process.map((step) => <li key={step}>{step}</li>)}</ol></> : null}
    <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 20 }}><ApplyFlow opportunity={opportunity} /><Link href={`/${opportunity.category === "jobs" ? "jobs" : opportunity.category}`} className="btn btn-outline" data-testid="button-opportunity-next-step">Back to {opportunity.category} <ArrowRight size={15} /></Link></div>
    </div><div className="card card-pad"><div className="eyebrow">Listing details</div><div className="resource-list" style={{ marginTop: 14 }}><div className="resource-item"><Building2 size={15} color="hsl(var(--accent))" /><span><strong>Organisation</strong><span>{opportunity.organization}</span></span></div><div className="resource-item"><Landmark size={15} color="hsl(var(--accent))" /><span><strong>Area</strong><span>{opportunity.lga}</span></span></div><div className="resource-item"><CircleAlert size={15} color="hsl(var(--accent))" /><span><strong>Deadline</strong><span>{dateLabel(opportunity.deadline)}</span></span></div><div className="resource-item"><CheckCircle2 size={15} color="hsl(var(--accent))" /><span><strong>Status</strong><span>{opportunity.status}</span></span></div></div>
    {related.length > 0 && <><div className="eyebrow" style={{ marginTop: 22 }}>Related opportunities</div><div className="resource-list" style={{ marginTop: 10 }}>{related.map((item) => <Link href={`/opportunities/${item.id}`} className="resource-item" key={item.id} data-testid={`link-related-${item.id}`}><Sparkles size={14} color="hsl(var(--accent))" /><span><strong>{item.title}</strong><span>{item.type}</span></span><ChevronRight size={14} style={{ marginLeft: "auto" }} /></Link>)}</div></>}
    </div></div> : <EmptyState title="Opportunity not found" copy="This listing may have moved." icon={CircleAlert} />}
    {!opportunity && <div style={{ marginTop: 16, textAlign: "center" }}><Link href="/jobs" className="btn btn-primary" data-testid="button-browse-opportunities">Browse opportunities <ArrowRight size={15} /></Link></div>}
    </div></main></Layout>;
}

function LgaDetail() {
  const { id = "" } = useParams<{ id: string }>();
  const lga = fallbackLgas.find((item) => item.id === id);
  return <Layout><PageHeading kicker="Katsina State · Local Government Area" title={lga?.name || "LGA not found"} description="A statewide prototype directory view for local government coverage and citizen-service access." /><main className="section"><div className="container-wide">{lga ? <div className="detail-grid"><div className="card card-pad">{lga.isPilot && <span className="tag tag-gold">Initial pilot focus</span>}<span className="tag" style={{ marginLeft: lga.isPilot ? 7 : 0 }}>DEMO DATA</span><h2 style={{ color: "hsl(var(--primary))", fontSize: "1.7rem", margin: "16px 0 8px" }}>{lga.name} Local Government Area</h2><p style={{ lineHeight: 1.7, fontSize: ".9rem" }}>{lga.description}</p><div style={{ display: "flex", gap: 9, flexWrap: "wrap", marginTop: 20 }}><Link href="/report" className="btn btn-primary" data-testid="button-lga-report">Report an issue <ArrowRight size={15} /></Link><Link href="/search" className="btn btn-outline" data-testid="button-lga-services">Find services</Link><Link href="/ai?q=What services are available in this LGA?" className="btn btn-outline" data-testid="button-lga-ai">Ask Civic AI</Link></div></div><div className="card card-pad"><div className="eyebrow">Pilot & statewide context</div><div className="resource-list" style={{ marginTop: 14 }}><div className="resource-item"><Landmark size={15} color="hsl(var(--accent))" /><span><strong>State</strong><span>Katsina State</span></span></div><div className="resource-item"><Landmark size={15} color="hsl(var(--accent))" /><span><strong>Statewide directory</strong><span>34 LGAs</span></span></div><div className="resource-item"><ShieldCheck size={15} color="hsl(var(--accent))" /><span><strong>Status</strong><span>{lga.isPilot ? "Initial pilot focus" : "Statewide prototype coverage"}</span></span></div></div></div></div> : <><EmptyState title="LGA not found" copy="Choose a local government area from the statewide directory." icon={CircleAlert} /><div style={{ marginTop: 16, textAlign: "center" }}><Link href="/government" className="btn btn-primary">View all 34 LGAs <ArrowRight size={15} /></Link></div></>}</div></main></Layout>;
}

function InfoDetail() {
  const { id = "" } = useParams<{ id: string }>();
  const resource = fallbackResources.find((item) => item.id === id);
  const government = demoGovernmentDirectory.find((item) => item.id === id);
  const news = demoNews.find((item) => item.id === id);
  const relatedResources = (resource?.relatedIds || []).map((relId) => fallbackOpportunities.find((o) => o.id === relId) || fallbackResources.find((r) => r.id === relId)).filter(Boolean);
  const title = resource?.title || government?.name || news?.title || "Not found";
  const kicker = resource ? "Resource detail" : government ? "Government directory" : news ? "News detail" : "Not found";
  const found = Boolean(resource || government || news);
  return <Layout><PageHeading kicker={kicker} title={title} description="A closer look with source, category and a clear next action." /><main className="section"><div className="container-wide">
    {resource && <div className="detail-grid"><div className="card card-pad"><span className="tag">{resource.category}</span> <span className="tag tag-gold">{resource.demoLabel}</span><h2 style={{ color: "hsl(var(--primary))", fontSize: "1.6rem", margin: "16px 0 7px" }}>{resource.title}</h2><p style={{ lineHeight: 1.7, fontSize: ".88rem" }}>{resource.description || resource.summary}</p><Link href={`/${resource.domain}`} className="btn btn-primary" style={{ marginTop: 16 }} data-testid="button-resource-next">{resource.actionLabel || "Explore this area"} <ArrowRight size={15} /></Link></div><div className="card card-pad"><div className="eyebrow">Source</div><div className="resource-list" style={{ marginTop: 14 }}><div className="resource-item"><FileText size={15} color="hsl(var(--accent))" /><span><strong>Source</strong><span>{resource.source || "Katsina Digital Pilot (demo)"}</span></span></div><div className="resource-item"><Landmark size={15} color="hsl(var(--accent))" /><span><strong>Domain</strong><span>{resource.domain}</span></span></div></div>{relatedResources.length > 0 && <><div className="eyebrow" style={{ marginTop: 20 }}>Related</div><div className="resource-list" style={{ marginTop: 10 }}>{relatedResources.map((item: any) => <Link href={item.title && item.organization ? `/opportunities/${item.id}` : `/resources/${item.id}`} className="resource-item" key={item.id}><Sparkles size={14} color="hsl(var(--accent))" /><span><strong>{item.title}</strong></span><ChevronRight size={14} style={{ marginLeft: "auto" }} /></Link>)}</div></>}</div></div>}
    {government && <div className="detail-grid"><div className="card card-pad"><span className="tag">{government.category}</span> <span className="tag tag-gold">{PROTOTYPE_TAG}</span><h2 style={{ color: "hsl(var(--primary))", fontSize: "1.6rem", margin: "16px 0 7px" }}>{government.name}</h2><p style={{ lineHeight: 1.7, fontSize: ".88rem" }}>{government.description}</p><div className="section-kicker" style={{ marginTop: 18 }}>Illustrative services</div><ul style={{ marginTop: 8, paddingLeft: 18, fontSize: ".85rem", lineHeight: 1.7 }}>{government.servicesOffered.map((svc) => <li key={svc}>{svc}</li>)}</ul><div style={{ display: "flex", gap: 9, flexWrap: "wrap", marginTop: 16 }}><Link href="/government" className="btn btn-primary" data-testid="button-government-next">Back to government directory <ArrowRight size={15} /></Link><Link href="/ai?q=What government services are available?" className="btn btn-outline" data-testid="button-government-ai">Ask Civic AI</Link></div></div><div className="card card-pad"><div className="eyebrow">Details</div><div className="resource-list" style={{ marginTop: 14 }}><div className="resource-item"><Landmark size={15} color="hsl(var(--accent))" /><span><strong>Location</strong><span>{government.location}</span></span></div><div className="resource-item"><MessageCircle size={15} color="hsl(var(--accent))" /><span><strong>Contact</strong><span>{government.demoContact}</span></span></div></div></div></div>}
    {news && <div className="detail-grid"><div className="card card-pad"><span className="tag">{news.category}</span> <span className="tag tag-gold">{news.sourceLabel}</span><h2 style={{ color: "hsl(var(--primary))", fontSize: "1.6rem", margin: "16px 0 7px" }}>{news.title}</h2><p className="form-help">{dateLabel(news.date)}</p><p style={{ lineHeight: 1.7, fontSize: ".88rem", marginTop: 14 }}>{news.body}</p><Link href="/government" className="btn btn-primary" style={{ marginTop: 16 }} data-testid="button-news-next">Back to government information <ArrowRight size={15} /></Link></div><div className="card card-pad"><div className="eyebrow">Source</div><div className="resource-list" style={{ marginTop: 14 }}><Link href="/government" className="resource-item resource-item-link" data-testid="link-news-source"><FileText size={15} color="hsl(var(--accent))" /><span><strong>Label</strong><span>{news.sourceLabel}</span><em>Open government information <ArrowRight size={13} /></em></span><ChevronRight size={14} style={{ marginLeft: "auto" }} /></Link></div></div></div>}
    {!found && <><EmptyState title="Not found" copy="This item may have moved. Try search or browse a service area." icon={CircleAlert} /><div style={{ marginTop: 16, textAlign: "center" }}><Link href="/search" className="btn btn-primary" data-testid="button-info-search">Search the catalog <ArrowRight size={15} /></Link></div></>}
  </div></main></Layout>;
}

function AppWithClerk() {
  return <ClerkProvider publishableKey={clerkPubKey} proxyUrl={clerkProxyUrl} appearance={{ theme: shadcn, cssLayerName: "clerk", options: { logoPlacement: "inside", logoLinkUrl: basePath || "/", logoImageUrl: `${window.location.origin}${basePath}/logo.svg` }, variables: { colorPrimary: "#0B5D3B", colorForeground: "#10231B", colorMutedForeground: "#64746D", colorBackground: "#F8FAF9", colorInput: "#FFFFFF", colorInputForeground: "#10231B", colorDanger: "#B3261E", colorNeutral: "#E4E9E6", fontFamily: "Manrope", borderRadius: "0.75rem" } }} signInUrl={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} routerPush={(to) => { window.history.pushState({}, "", to); window.dispatchEvent(new PopStateEvent("popstate")); }} routerReplace={(to) => { window.history.replaceState({}, "", to); window.dispatchEvent(new PopStateEvent("popstate")); }}><Router /></ClerkProvider>;
}

function App() { return <QueryClientProvider client={queryClient}><DemoStoreProvider><WouterRouter base={basePath}>{clerkPubKey ? <AppWithClerk /> : <Router />}</WouterRouter></DemoStoreProvider></QueryClientProvider>; }

export default App;