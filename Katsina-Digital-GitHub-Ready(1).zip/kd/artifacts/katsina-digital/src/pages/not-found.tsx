import { Link } from "wouter";
import { ArrowRight, CircleAlert, Search } from "lucide-react";

export default function NotFound() {
  return (
    <div className="page-shell">
      <main className="section" style={{ minHeight: "70vh", display: "flex", alignItems: "center" }}>
        <div className="container-wide">
          <div className="empty-state" data-testid="empty-not-found" style={{ maxWidth: 560, margin: "0 auto" }}>
            <CircleAlert size={30} />
            <strong>Page not found</strong>
            <span>This page may have moved, or the link may be out of date. Try searching, or return to the homepage.</span>
            <div style={{ display: "flex", gap: 9, flexWrap: "wrap", justifyContent: "center", marginTop: 16 }}>
              <Link href="/" className="btn btn-primary" data-testid="link-notfound-home">
                Return home <ArrowRight size={15} />
              </Link>
              <Link href="/search" className="btn btn-outline" data-testid="link-notfound-search">
                <Search size={15} /> Search the catalog
              </Link>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
