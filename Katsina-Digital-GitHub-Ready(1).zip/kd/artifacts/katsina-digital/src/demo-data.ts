// ---------------------------------------------------------------------------
// Katsina Civic Digital — centralized demo / prototype data layer.
//
// Every value in this file is illustrative demonstration content for the
// V1.0 concept prototype. Nothing here represents verified, live government
// information. Keep all demo content here instead of scattering objects
// through components, so the story stays internally consistent (dashboard
// counts, tracked reports, opportunity details, etc. all read from one
// source of truth).
// ---------------------------------------------------------------------------
import type { Lga, Opportunity, Report, Resource } from "@workspace/api-client-react";

export const DEMO_LABEL = "DEMO DATA";
export const PROTOTYPE_LABEL = "PROTOTYPE CONTENT";

// ---------------------------------------------------------------------------
// Demo citizen profile — used to pre-fill forms across the prototype.
// ---------------------------------------------------------------------------
export const demoUser = {
  name: "Ibrahim Salisu Musawa",
  email: "isalisuhalilu@gmail.com",
  phone: "07040517038",
  role: "citizen" as const,
  lga: "Musawa",
  joinedAt: "2026-02-11T09:00:00.000Z",
};

// ---------------------------------------------------------------------------
// Katsina State has 34 Local Government Areas. The prototype keeps the
// names complete locally so forms and demo navigation work without the API.
export const fallbackLgas: Lga[] = [
  { id: "bakori", name: "Bakori", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "batagarawa", name: "Batagarawa", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "batsari", name: "Batsari", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "baure", name: "Baure", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "bindawa", name: "Bindawa", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "charanchi", name: "Charanchi", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "dandume", name: "Dandume", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "danja", name: "Danja", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "danmusa", name: "Danmusa", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "daura", name: "Daura", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "dutsi", name: "Dutsi", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "dutsin-ma", name: "Dutsin-ma", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "faskari", name: "Faskari", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "funtua", name: "Funtua", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "ingawa", name: "Ingawa", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "jibia", name: "Jibia", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "kafur", name: "Kafur", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "kaita", name: "Kaita", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "kankara", name: "Kankara", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "kankiya", name: "Kankiya", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "katsina", name: "Katsina", isPilot: true, description: "Initial pilot LGA within the Katsina State statewide concept." },
  { id: "kurfi", name: "Kurfi", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "kusada", name: "Kusada", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "mai-adua", name: "Mai'adua", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "malumfashi", name: "Malumfashi", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "mani", name: "Mani", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "mashi", name: "Mashi", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "matazu", name: "Matazu", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "musawa", name: "Musawa", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "rimi", name: "Rimi", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "sabuwa", name: "Sabuwa", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "safana", name: "Safana", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "sandamu", name: "Sandamu", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
  { id: "zango", name: "Zango", isPilot: false, description: "Katsina State LGA — prototype directory entry." },
];

// ---------------------------------------------------------------------------
// Opportunities — scholarships, jobs, internships, training, youth,
// entrepreneurship, agriculture and health opportunities.
// ---------------------------------------------------------------------------
export interface DemoOpportunity extends Opportunity {
  eligibility?: string;
  requirements?: string[];
  process?: string[];
  relatedIds?: string[];
}

export const demoOpportunities: DemoOpportunity[] = [
  {
    id: "opp-scholarship-state",
    title: "Katsina State Scholarship Scheme",
    organization: "Katsina State Scholarship Board (demo)",
    category: "education",
    type: "Scholarship",
    lga: "All LGAs",
    deadline: "2026-10-15",
    description: "A prototype listing showing how a statewide undergraduate scholarship could be presented, including eligibility and required documents.",
    sourceLabel: DEMO_LABEL,
    status: "Open for demonstration",
    featured: true,
    eligibility: "Indigenes of Katsina State currently enrolled in an accredited tertiary institution.",
    requirements: ["Local Government indigene certificate", "Admission letter or current student ID", "Most recent academic transcript"],
    process: ["Create a prototype profile", "Complete the application form", "Upload supporting documents", "Await review (demo status only)"],
    relatedIds: ["opp-scholarship-stem", "res-education-scholarships"],
  },
  {
    id: "opp-scholarship-stem",
    title: "Musawa Girls' STEM Scholarship",
    organization: "Musawa Education Desk (demo)",
    category: "education",
    type: "Scholarship",
    lga: "Musawa",
    deadline: "2026-09-30",
    description: "A sample scholarship listing focused on encouraging girls in Musawa LGA into science and technology study paths.",
    sourceLabel: DEMO_LABEL,
    status: "Sample listing",
    featured: true,
    eligibility: "Female secondary school leavers resident in Musawa LGA with an interest in STEM fields.",
    requirements: ["WAEC/NECO result (or pending)", "Local Government attestation", "Short statement of interest"],
    process: ["Register interest", "Attend a prototype briefing session", "Submit documents for review"],
    relatedIds: ["opp-scholarship-state", "res-education-admissions"],
  },
  {
    id: "opp-bursary-waec",
    title: "WAEC / NECO Examination Bursary",
    organization: "Katsina State Ministry of Education (demo)",
    category: "education",
    type: "Bursary",
    lga: "All LGAs",
    deadline: "2026-11-01",
    description: "A demo bursary listing that shows how exam-fee support could be structured for indigent students.",
    sourceLabel: DEMO_LABEL,
    status: "Sample listing",
    featured: false,
    eligibility: "Final-year secondary students from low-income households.",
    requirements: ["School attestation letter", "Local Government indigence letter"],
    process: ["Submit prototype interest form", "School verifies eligibility", "Demo confirmation issued"],
    relatedIds: ["opp-scholarship-state"],
  },
  {
    id: "opp-youth-skills",
    title: "Katsina Youth Skills Cohort",
    organization: "Katsina Digital Pilot (demo)",
    category: "jobs",
    type: "Training",
    lga: "Musawa",
    deadline: "2026-10-18",
    description: "Practical digital and enterprise skills for young residents in Musawa LGA, demonstrated as a full opportunity listing.",
    sourceLabel: DEMO_LABEL,
    status: "Open for demonstration",
    featured: true,
    eligibility: "Residents of Musawa LGA aged 18–35.",
    requirements: ["Valid means of identification", "Completed intake form"],
    process: ["Register interest", "Attend a placement interview (demo)", "Join the training cohort"],
    relatedIds: ["opp-digital-internship", "opp-enterprise-grant"],
  },
  {
    id: "opp-digital-internship",
    title: "State Digital Internship Programme",
    organization: "Katsina State Digital Economy Office (demo)",
    category: "jobs",
    type: "Internship",
    lga: "Katsina",
    deadline: "2026-09-25",
    description: "A sample internship listing for graduates seeking practical experience in digital public service delivery.",
    sourceLabel: DEMO_LABEL,
    status: "Sample listing",
    featured: false,
    eligibility: "Recent graduates (within 3 years) with an interest in public digital services.",
    requirements: ["CV", "Degree certificate or statement of result", "Cover note"],
    process: ["Submit prototype application", "Shortlisting (demo)", "Onboarding briefing"],
    relatedIds: ["opp-youth-skills", "res-jobs-cv"],
  },
  {
    id: "opp-admin-officer",
    title: "Local Government Administrative Officer",
    organization: "Musawa Local Government Secretariat (demo)",
    category: "jobs",
    type: "Job",
    lga: "Musawa",
    deadline: "2026-09-20",
    description: "A demo civil-service job listing illustrating how open local government roles could be published and applied for.",
    sourceLabel: DEMO_LABEL,
    status: "Sample listing",
    featured: false,
    eligibility: "Minimum of OND/HND in Public Administration or related field.",
    requirements: ["Application letter", "Curriculum vitae", "Credentials"],
    process: ["Submit prototype application", "Screening (demo)", "Interview invitation (demo)"],
    relatedIds: ["opp-digital-internship"],
  },
  {
    id: "opp-enterprise-grant",
    title: "Musawa Enterprise Starter Grant",
    organization: "Musawa Enterprise Desk (demo)",
    category: "jobs",
    type: "Entrepreneurship",
    lga: "Musawa",
    deadline: "2026-11-10",
    description: "A sample small-grant listing for first-time entrepreneurs, shown here as a full prototype opportunity.",
    sourceLabel: DEMO_LABEL,
    status: "Open for demonstration",
    featured: false,
    eligibility: "Residents of Musawa LGA with an early-stage business idea or existing micro-business.",
    requirements: ["Simple business summary (1 page)", "Valid means of identification"],
    process: ["Register interest", "Pitch review (demo)", "Grant briefing (demo)"],
    relatedIds: ["opp-youth-skills"],
  },
  {
    id: "opp-youth-volunteer",
    title: "Youth Volunteer Corps",
    organization: "Katsina Civic Engagement Desk (demo)",
    category: "jobs",
    type: "Volunteer",
    lga: "All LGAs",
    deadline: "2026-10-05",
    description: "A demo listing showing how volunteer placements connecting youth to community projects could be organised.",
    sourceLabel: DEMO_LABEL,
    status: "Sample listing",
    featured: false,
    eligibility: "Residents aged 16 and above interested in community service.",
    requirements: ["Registration form", "Guardian consent (if under 18)"],
    process: ["Register interest", "Orientation session (demo)", "Placement (demo)"],
    relatedIds: ["opp-community-health"],
  },
  {
    id: "opp-farm-input",
    title: "Smallholder Farm Input Support",
    organization: "Agriculture desk (demo)",
    category: "agriculture",
    type: "Grant",
    lga: "Musawa",
    deadline: "2026-09-04",
    description: "A prototype listing for seasonal input and advisory support for smallholder farmers.",
    sourceLabel: DEMO_LABEL,
    status: "Open for demonstration",
    featured: true,
    eligibility: "Registered smallholder farmers in Musawa LGA.",
    requirements: ["Farmer registration number (demo)", "Plot location details"],
    process: ["Register interest", "Field verification (demo)", "Input distribution (demo)"],
    relatedIds: ["opp-irrigation-training", "res-agri-market"],
  },
  {
    id: "opp-irrigation-training",
    title: "Dry Season Irrigation Support Training",
    organization: "Katsina State Ministry of Agriculture (demo)",
    category: "agriculture",
    type: "Training",
    lga: "All LGAs",
    deadline: "2026-10-22",
    description: "A demo training listing showing dry-season irrigation guidance for farming communities.",
    sourceLabel: DEMO_LABEL,
    status: "Sample listing",
    featured: false,
    eligibility: "Farmers and cooperative members across pilot LGAs.",
    requirements: ["Cooperative membership (or individual registration)"],
    process: ["Register interest", "Attend training session (demo)", "Receive completion note (demo)"],
    relatedIds: ["opp-farm-input"],
  },
  {
    id: "opp-agro-processing",
    title: "Agro-Processing Youth Cohort",
    organization: "Musawa Enterprise Desk (demo)",
    category: "agriculture",
    type: "Entrepreneurship",
    lga: "Musawa",
    deadline: "2026-11-15",
    description: "A sample cohort listing pairing young residents with agro-processing business skills.",
    sourceLabel: DEMO_LABEL,
    status: "Sample listing",
    featured: false,
    eligibility: "Residents of Musawa LGA aged 18–35 with an interest in agribusiness.",
    requirements: ["Registration form", "Short statement of interest"],
    process: ["Register interest", "Cohort selection (demo)", "Skills sessions (demo)"],
    relatedIds: ["opp-farm-input", "opp-enterprise-grant"],
  },
  {
    id: "opp-community-health",
    title: "Community Health Volunteers",
    organization: "Public health programme (demo)",
    category: "health",
    type: "Volunteer",
    lga: "All LGAs",
    deadline: "2026-10-30",
    description: "Learn how communities could support health information and referral through trained local volunteers.",
    sourceLabel: DEMO_LABEL,
    status: "Open for demonstration",
    featured: true,
    eligibility: "Residents aged 18 and above with good community standing.",
    requirements: ["Registration form", "Basic literacy in Hausa or English"],
    process: ["Register interest", "Orientation training (demo)", "Community placement (demo)"],
    relatedIds: ["opp-maternal-health", "opp-youth-volunteer"],
  },
  {
    id: "opp-maternal-health",
    title: "Maternal Health Outreach Training",
    organization: "Katsina State Primary Healthcare Development Agency (demo)",
    category: "health",
    type: "Training",
    lga: "All LGAs",
    deadline: "2026-09-28",
    description: "A demo training listing for outreach workers supporting maternal and child health awareness.",
    sourceLabel: DEMO_LABEL,
    status: "Sample listing",
    featured: false,
    eligibility: "Existing community or health volunteers.",
    requirements: ["Proof of prior volunteer registration (demo)"],
    process: ["Register interest", "Attend training (demo)", "Receive completion note (demo)"],
    relatedIds: ["opp-community-health"],
  },
];

export const fallbackOpportunities = demoOpportunities;

// ---------------------------------------------------------------------------
// Resources — one directory shelf per service domain.
// ---------------------------------------------------------------------------
export interface DemoResource extends Resource {
  description?: string;
  source?: string;
  relatedIds?: string[];
}

export const demoResources: DemoResource[] = [
  { id: "res-education-scholarships", title: "Scholarships", domain: "education", category: "Education", summary: "Find and compare scholarship information in one place.", demoLabel: DEMO_LABEL, actionLabel: "Explore scholarships", description: "A directory shelf showing how verified scholarship listings, deadlines and eligibility notes could be organised for residents once real programmes are onboarded.", source: "Katsina State Scholarship Board (demo)", relatedIds: ["opp-scholarship-state", "opp-scholarship-stem"] },
  { id: "res-education-admissions", title: "Admissions & JAMB", domain: "education", category: "Education", summary: "A future-ready guide to admissions, JAMB, WAEC and NECO resources.", demoLabel: DEMO_LABEL, actionLabel: "View education resources", description: "This shelf is prepared to hold admissions timelines, JAMB guidance and examination-body contacts once verified by the Ministry of Education.", source: "Katsina State Ministry of Education (demo)", relatedIds: ["opp-bursary-waec"] },
  { id: "res-education-learning", title: "Learning resources", domain: "education", category: "Education", summary: "Study support and learning links can live here as they are verified.", demoLabel: DEMO_LABEL, actionLabel: "Browse resources", description: "A placeholder shelf for locally relevant study guides, past-question archives and library information once sourced and verified.", source: "Katsina Digital Pilot (demo)" },
  { id: "res-jobs-opportunities", title: "Jobs & internships", domain: "jobs", category: "Jobs & Skills", summary: "A single place for jobs, internships and local skills opportunities.", demoLabel: DEMO_LABEL, actionLabel: "Find opportunities", description: "Aggregates open roles, internships and training cohorts from the opportunity catalog into one browsing shelf.", source: "Katsina Digital Pilot (demo)", relatedIds: ["opp-digital-internship", "opp-admin-officer"] },
  { id: "res-jobs-cv", title: "CV assistance", domain: "jobs", category: "Jobs & Skills", summary: "Practical CV guidance designed for first-time and returning job seekers.", demoLabel: DEMO_LABEL, actionLabel: "Get CV guidance", description: "A prototype shelf for CV templates and interview-preparation notes tailored to first-time applicants.", source: "Katsina Digital Pilot (demo)" },
  { id: "res-agri-information", title: "Farming information", domain: "agriculture", category: "Agriculture", summary: "Seasonal farming resources and practical information for growers.", demoLabel: DEMO_LABEL, actionLabel: "Explore agriculture", description: "Holds seasonal planting calendars and extension-service guidance once verified by the Ministry of Agriculture.", source: "Katsina State Ministry of Agriculture (demo)", relatedIds: ["opp-irrigation-training"] },
  { id: "res-agri-market", title: "Market information", domain: "agriculture", category: "Agriculture", summary: "Market information could help farmers make more informed decisions.", demoLabel: DEMO_LABEL, actionLabel: "View market resources", description: "Illustrative only — this shelf is not connected to live market prices. It shows how market-signal summaries could be presented.", source: "Illustrative example — not a live price feed", relatedIds: ["opp-farm-input"] },
  { id: "res-health-facilities", title: "Health facilities", domain: "health", category: "Health", summary: "A directory structure for verified facilities and public health resources.", demoLabel: DEMO_LABEL, actionLabel: "Explore health resources", description: "A directory shelf prepared to list verified primary healthcare centres once confirmed by the Primary Healthcare Development Agency.", source: "Katsina State Primary Healthcare Development Agency (demo)" },
  { id: "res-health-information", title: "Health information", domain: "health", category: "Health", summary: "Plain-language health information can be published here when verified.", demoLabel: DEMO_LABEL, actionLabel: "Browse health information", description: "Illustrative only — no medical statistics or official programme data is included in this prototype.", source: "Illustrative example — not official health guidance", relatedIds: ["opp-community-health", "opp-maternal-health"] },
  { id: "res-government-information", title: "Government information", domain: "government", category: "Government", summary: "A structured place for ministries, agencies and public programmes.", demoLabel: DEMO_LABEL, actionLabel: "Explore government information", description: "Links through to the government directory shelf covering ministries, agencies and public offices in this prototype.", source: "Katsina Digital Pilot (demo)" },
  { id: "res-government-announcements", title: "Announcements", domain: "government", category: "Government", summary: "Announcements should only appear here after they are verified and sourced.", demoLabel: "DEMO DATA — No real announcement", actionLabel: "View demo announcements", description: "Every announcement shown in this prototype is illustrative content used to demonstrate layout and structure only.", source: "Katsina Digital Pilot (demo)" },
];

export const fallbackResources = demoResources;

// ---------------------------------------------------------------------------
// Government directory — ministries, departments, agencies, public offices.
// ---------------------------------------------------------------------------
export interface GovernmentEntry {
  id: string;
  name: string;
  category: "Ministry" | "Department" | "Agency" | "Public Office";
  description: string;
  servicesOffered: string[];
  location: string;
  demoContact: string;
}

export const demoGovernmentDirectory: GovernmentEntry[] = [
  { id: "gov-ministry-education", name: "Katsina State Ministry of Education", category: "Ministry", description: "Illustrative directory entry for the ministry responsible for basic, secondary and tertiary education policy.", servicesOffered: ["Scholarship policy", "School admissions guidance", "Examination coordination"], location: "Katsina, Katsina State (illustrative)", demoContact: "Demo contact — not a verified line" },
  { id: "gov-ministry-health", name: "Katsina State Ministry of Health", category: "Ministry", description: "Illustrative directory entry for the ministry overseeing public health policy and facilities.", servicesOffered: ["Public health guidance", "Facility oversight", "Health programme coordination"], location: "Katsina, Katsina State (illustrative)", demoContact: "Demo contact — not a verified line" },
  { id: "gov-ministry-agriculture", name: "Katsina State Ministry of Agriculture and Natural Resources", category: "Ministry", description: "Illustrative directory entry for the ministry supporting farmers and agricultural development.", servicesOffered: ["Extension services", "Input support coordination", "Irrigation guidance"], location: "Katsina, Katsina State (illustrative)", demoContact: "Demo contact — not a verified line" },
  { id: "gov-ministry-youth", name: "Katsina State Ministry of Youth and Social Development", category: "Ministry", description: "Illustrative directory entry for the ministry coordinating youth empowerment and social programmes.", servicesOffered: ["Youth training coordination", "Volunteer programme oversight", "Enterprise support"], location: "Katsina, Katsina State (illustrative)", demoContact: "Demo contact — not a verified line" },
  { id: "gov-agency-scholarship-board", name: "Katsina State Scholarship Board", category: "Agency", description: "Illustrative directory entry for the agency that would administer statewide scholarship schemes.", servicesOffered: ["Scholarship administration", "Bursary verification"], location: "Katsina, Katsina State (illustrative)", demoContact: "Demo contact — not a verified line" },
  { id: "gov-agency-phcda", name: "Katsina State Primary Healthcare Development Agency", category: "Agency", description: "Illustrative directory entry for the agency overseeing primary healthcare delivery.", servicesOffered: ["Primary healthcare coordination", "Community health volunteer programmes"], location: "Katsina, Katsina State (illustrative)", demoContact: "Demo contact — not a verified line" },
  { id: "gov-agency-statistics", name: "Katsina State Bureau of Statistics", category: "Agency", description: "Illustrative directory entry for the agency responsible for official state statistics.", servicesOffered: ["Data publication", "Survey coordination"], location: "Katsina, Katsina State (illustrative)", demoContact: "Demo contact — not a verified line" },
  { id: "gov-office-musawa-secretariat", name: "Musawa Local Government Secretariat", category: "Public Office", description: "Illustrative directory entry for Musawa LGA's local government secretariat.", servicesOffered: ["Local government administration", "Indigene certification", "Community liaison"], location: "Musawa LGA", demoContact: "Demo contact — not a verified line" },
];

// ---------------------------------------------------------------------------
// News & announcements
// ---------------------------------------------------------------------------
export interface NewsItem {
  id: string;
  title: string;
  category: string;
  summary: string;
  body: string;
  date: string;
  sourceLabel: string;
}

export const demoNews: NewsItem[] = [
  { id: "news-pilot-launch", title: "Katsina LGA pilot enters concept testing phase", category: "Pilot update", date: "2026-08-20", summary: "A demo announcement showing how the Katsina LGA pilot concept could be communicated to residents.", body: "This illustrative announcement demonstrates how the Katsina Civic Digital team could share pilot milestones with residents of Katsina LGA. No real testing programme is described here — this is prototype content only, used to show layout and tone.", sourceLabel: "DEMO / PROTOTYPE CONTENT" },
  { id: "news-skills-cohort-open", title: "Digital skills cohort applications open (demo)", category: "Opportunities", date: "2026-08-18", summary: "A sample announcement pointing residents toward the Katsina Youth Skills Cohort listing.", body: "This illustrative announcement shows how an opportunity could be promoted through the news shelf. See the Katsina Youth Skills Cohort listing under Jobs & Skills for the full prototype detail view.", sourceLabel: "DEMO / PROTOTYPE CONTENT" },
  { id: "news-scholarship-finder", title: "Prototype scholarship finder added to catalog", category: "Education", date: "2026-08-12", summary: "A sample note describing the addition of a demo scholarship directory shelf.", body: "This illustrative update describes how new resource shelves could be announced as they are added to the prototype catalog. No real scholarship programme is confirmed by this note.", sourceLabel: "DEMO / PROTOTYPE CONTENT" },
  { id: "news-reporting-demo", title: "Community reporting tool demonstration begins", category: "Civic engagement", date: "2026-08-05", summary: "A sample announcement introducing the Report an Issue prototype flow.", body: "This illustrative announcement shows how the civic reporting workflow — submission, reference number and tracking — could be introduced to residents during a demonstration period.", sourceLabel: "DEMO / PROTOTYPE CONTENT" },
];

// ---------------------------------------------------------------------------
// Reports — a small, internally consistent seed set used whenever the
// prototype is viewed without a signed-in session (or if the API is
// unreachable). Dashboard counts are derived from this same list so numbers
// always agree with what is shown in Reports and Tracking.
// ---------------------------------------------------------------------------
export const demoReports: Report[] = [
  { id: "demo-report-1", reportId: "KD-2026-AB1234", category: "Roads and drainage", description: "A demo record showing a drainage blockage near Musawa Central Market that has since been marked resolved in this prototype.", photoPath: null, lga: "Musawa", location: "Near Musawa Central Market", status: "resolved", createdAt: "2026-08-05T08:15:00.000Z", updatedAt: "2026-08-14T10:00:00.000Z" },
  { id: "demo-report-2", reportId: "KD-2026-CD5678", category: "Water", description: "A demo record showing a reported borehole fault currently marked in progress in this prototype.", photoPath: null, lga: "Musawa", location: "Sabon Gari ward, Musawa", status: "in_progress", createdAt: "2026-08-21T07:40:00.000Z", updatedAt: "2026-08-27T09:10:00.000Z" },
  { id: "demo-report-3", reportId: "KD-2026-EF9012", category: "Waste", description: "A demo record showing an uncollected waste report currently marked under review in this prototype.", photoPath: null, lga: "Katsina", location: "Kofar Kaura area, Katsina", status: "under_review", createdAt: "2026-08-27T13:20:00.000Z", updatedAt: "2026-08-28T09:00:00.000Z" },
  { id: "demo-report-4", reportId: "KD-2026-GH3456", category: "Electricity", description: "A demo record showing a recently submitted streetlight fault report, shown here as freshly submitted.", photoPath: null, lga: "Musawa", location: "Along Musawa–Dutsin-Ma road", status: "submitted", createdAt: "2026-08-31T18:05:00.000Z", updatedAt: "2026-08-31T18:05:00.000Z" },
];

// ---------------------------------------------------------------------------
// Notifications & saved items
// ---------------------------------------------------------------------------
export interface DemoNotification {
  id: string;
  title: string;
  body: string;
  date: string;
  read: boolean;
}

export const demoNotifications: DemoNotification[] = [
  { id: "notif-1", title: "Report KD-2026-CD5678 moved to In Progress", body: "Your water report is now being worked on in this prototype's tracking timeline.", date: "2026-08-27T09:10:00.000Z", read: false },
  { id: "notif-2", title: "New opportunity: State Digital Internship Programme", body: "A new internship listing was added to Jobs & Skills.", date: "2026-08-25T11:00:00.000Z", read: false },
  { id: "notif-3", title: "Community Health Volunteers applications closing soon", body: "This demo opportunity listing closes on 30 October 2026.", date: "2026-08-22T08:30:00.000Z", read: true },
  { id: "notif-4", title: "Welcome to Katsina Civic Digital", body: "Explore your dashboard, report an issue or ask Civic AI to see how the pilot concept works.", date: "2026-08-11T09:00:00.000Z", read: true },
];

export const demoSavedItemIds = ["res-education-scholarships", "opp-youth-skills", "gov-agency-scholarship-board"];

// ---------------------------------------------------------------------------
// Admin — demo users & roles table
// ---------------------------------------------------------------------------
export const demoAdminUsers = [
  { id: "u-1", name: demoUser.name, email: demoUser.email, role: "citizen", status: "Active (demo)" },
  { id: "u-2", name: "Hauwa Bello", email: "hauwa.bello@example.com", role: "staff", status: "Active (demo)" },
  { id: "u-3", name: "Aminu Garba", email: "aminu.garba@example.com", role: "admin", status: "Active (demo)" },
  { id: "u-4", name: "Zainab Yusuf", email: "zainab.yusuf@example.com", role: "citizen", status: "Active (demo)" },
  { id: "u-5", name: "Suleiman Idris", email: "suleiman.idris@example.com", role: "citizen", status: "Invited (demo)" },
];

// ---------------------------------------------------------------------------
// Search index — flattens the catalog into one shape for global search.
// ---------------------------------------------------------------------------
export type SearchResult = {
  id: string;
  kind: "opportunity" | "resource" | "government" | "news" | "service";
  title: string;
  summary: string;
  href: string;
  tag: string;
};

export function buildSearchIndex(): SearchResult[] {
  const opportunityResults: SearchResult[] = demoOpportunities.map((item) => ({ id: item.id, kind: "opportunity", title: item.title, summary: item.description, href: `/opportunities/${item.id}`, tag: item.type }));
  const resourceResults: SearchResult[] = demoResources.map((item) => ({ id: item.id, kind: "resource", title: item.title, summary: item.summary, href: `/resources/${item.id}`, tag: item.category }));
  const governmentResults: SearchResult[] = demoGovernmentDirectory.map((item) => ({ id: item.id, kind: "government", title: item.name, summary: item.description, href: `/government/${item.id}`, tag: item.category }));
  const newsResults: SearchResult[] = demoNews.map((item) => ({ id: item.id, kind: "news", title: item.title, summary: item.summary, href: `/news/${item.id}`, tag: item.category }));
  const serviceResults: SearchResult[] = [
    { id: "svc-education", kind: "service", title: "Education", summary: "Scholarships, admissions and learning resources.", href: "/education", tag: "Service area" },
    { id: "svc-jobs", kind: "service", title: "Jobs & Skills", summary: "Jobs, internships, training and enterprise opportunities.", href: "/jobs", tag: "Service area" },
    { id: "svc-agriculture", kind: "service", title: "Agriculture", summary: "Farming information, markets, support and opportunities.", href: "/agriculture", tag: "Service area" },
    { id: "svc-health", kind: "service", title: "Health", summary: "Health information, facilities and public programmes.", href: "/health", tag: "Service area" },
    { id: "svc-government", kind: "service", title: "Government", summary: "Government information, offices and public services.", href: "/government", tag: "Service area" },
  ];
  return [...serviceResults, ...opportunityResults, ...resourceResults, ...governmentResults, ...newsResults];
}

export const suggestedSearches = ["scholarship", "jobs", "training", "agriculture", "health", "roads", "water", "electricity", "education", "government", "youth"];
